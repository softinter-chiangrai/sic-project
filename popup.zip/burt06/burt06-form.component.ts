// sic-app/src/app/feature/bu/rt/burt06/burt06-form.component.ts
import { CommonModule } from '@angular/common';
import { Component, inject, Input, OnInit, signal } from '@angular/core';
import { FormArray, FormBuilder, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { SicButtonComponent } from '../../../../core/component/sic-button/sic-button.component';
import { SicInputAreaComponent } from '../../../../core/component/sic-input-area/sic-input-area.component';
import { SicInputComponent } from '../../../../core/component/sic-input/sic-input.component';
import { SicNumberComponent } from '../../../../core/component/sic-number/sic-number.component';
import { SicCheckboxComponent } from '../../../../core/component/sic-checkbox/sic-checkbox.component';
import { DialogService } from '../../../../core/services/dialog.service';
import { ApprovalFlow, ApprovalFlowStep, Burt06Service } from './burt06.service';

// Static options
const DOCUMENT_TYPE_OPTIONS = [
  { value: 'REQUIREMENT', text: 'Requirement' },
  { value: 'SPECIFICATION', text: 'Specification' },
  { value: 'DFD', text: 'DFD' },
  { value: 'ER', text: 'ER Diagram' },
  { value: 'DELIVERY', text: 'Delivery' },
  { value: 'INVOICE', text: 'Invoice' },
  { value: 'MA_RENEWAL', text: 'MA Renewal' },
  { value: 'CHANGE_REQUEST', text: 'Change Request' },
  { value: 'TEST_PLAN', text: 'Test Plan' },
  { value: 'UAT', text: 'UAT' },
];

const APPROVAL_MODE_OPTIONS = [
  { value: 'CHAIN', text: 'เรียงลำดับ (Chain)' },
  { value: 'PARALLEL', text: 'พร้อมกัน (Parallel)' },
  { value: 'ANY', text: 'ใครก็ได้ (Any)' },
  { value: 'SINGLE', text: 'คนเดียว (Single)' },
];

@Component({
  selector: 'app-burt06-form',
  standalone: true,
  imports: [
    CommonModule,
    ReactiveFormsModule,
    SicButtonComponent,
    SicInputComponent,
    SicNumberComponent,
    SicInputAreaComponent,
    SicCheckboxComponent,
  ],
  template: `
    <div class="w-[min(92vw,48rem)] max-h-[90vh] overflow-hidden rounded-2xl border bg-[var(--bg)] text-[var(--text)] shadow-2xl">
      <div class="px-6 py-4 border-b border-[var(--border)] flex items-center justify-between">
        <h3 class="text-lg font-semibold text-[var(--text-active)]">
          {{ flowId ? 'แก้ไข' : 'สร้าง' }} Approval Flow
        </h3>
        <button (click)="cancel()" class="text-[var(--text-muted)] hover:text-[var(--text-active)]">
          <i class="bi bi-x-lg"></i>
        </button>
      </div>

      <div class="p-6 overflow-y-auto max-h-[calc(90vh-8rem)]">
        <form [formGroup]="form">
          <!-- Basic Info -->
          <div class="grid grid-cols-2 gap-4">
            <sic-input label="รหัส Flow" formControlName="flowCode" [required]="true" placeholder="REQ_APPROVAL"></sic-input>
            <sic-input label="ชื่อ Flow" formControlName="flowName" [required]="true" placeholder="Requirement Approval"></sic-input>
          </div>

          <div class="grid grid-cols-2 gap-4 mt-3">
            <!-- เปลี่ยนเป็น select แทน combobox -->
            <div>
              <label class="block text-sm font-medium text-[var(--text-active)] mb-1">ประเภทเอกสาร <span class="text-red-500">*</span></label>
              <select
                formControlName="documentType"
                class="w-full px-3 py-2 rounded-lg border border-[var(--border)] bg-[var(--bg)] text-[var(--text)] text-sm focus:outline-none focus:ring-2 focus:ring-[var(--crm-primary)]/20 focus:border-[var(--crm-primary)] appearance-none pr-8 transition-all"
              >
                <option value="">-- เลือก --</option>
                @for (opt of documentTypeOptions; track opt.value) {
                  <option [value]="opt.value">{{ opt.text }}</option>
                }
              </select>
              @if (form.get('documentType')?.touched && form.get('documentType')?.invalid) {
                <p class="text-xs text-[var(--crm-danger)] mt-1">กรุณาเลือกประเภทเอกสาร</p>
              }
            </div>

            <div>
              <label class="block text-sm font-medium text-[var(--text-active)] mb-1">โหมดการอนุมัติ <span class="text-red-500">*</span></label>
              <select
                formControlName="approvalMode"
                class="w-full px-3 py-2 rounded-lg border border-[var(--border)] bg-[var(--bg)] text-[var(--text)] text-sm focus:outline-none focus:ring-2 focus:ring-[var(--crm-primary)]/20 focus:border-[var(--crm-primary)] appearance-none pr-8 transition-all"
              >
                @for (opt of approvalModeOptions; track opt.value) {
                  <option [value]="opt.value">{{ opt.text }}</option>
                }
              </select>
              @if (form.get('approvalMode')?.touched && form.get('approvalMode')?.invalid) {
                <p class="text-xs text-[var(--crm-danger)] mt-1">กรุณาเลือกโหมด</p>
              }
            </div>
          </div>

          <sic-input-area label="คำอธิบาย" formControlName="description" [rows]="2" class="mt-3"></sic-input-area>

          <div class="flex items-center gap-3 mt-3">
            <sic-checkbox label="เปิดใช้งาน" formControlName="isActive"></sic-checkbox>
          </div>

          <!-- Steps -->
          <div class="mt-6 border-t border-[var(--border)] pt-4">
            <div class="flex items-center justify-between mb-3">
              <h4 class="text-sm font-semibold text-[var(--text-active)]">ขั้นตอนการอนุมัติ</h4>
              <button
                type="button"
                (click)="addStep()"
                class="inline-flex items-center gap-1 px-3 py-1 text-sm text-[var(--crm-primary)] hover:underline"
              >
                <i class="bi bi-plus-lg"></i> เพิ่มขั้นตอน
              </button>
            </div>

            <div formArrayName="steps" class="space-y-3">
              @for (step of steps.controls; track $index; let i = $index) {
                <div [formGroupName]="i" class="border border-[var(--border)] rounded-lg p-4 bg-[var(--sidebar)]/50">
                  <div class="flex justify-between items-start">
                    <span class="text-sm font-medium text-[var(--text-muted)]">ขั้นตอนที่ {{ i + 1 }}</span>
                    <button
                      type="button"
                      (click)="removeStep(i)"
                      class="text-[var(--text-muted)] hover:text-[var(--crm-danger)]"
                    >
                      <i class="bi bi-trash"></i>
                    </button>
                  </div>

                  <div class="grid grid-cols-2 gap-3 mt-2">
                    <sic-input label="ชื่อขั้นตอน" formControlName="stepName" [required]="true" placeholder="BA Approve"></sic-input>
                    <sic-input label="บทบาทผู้ Approve" formControlName="approverRole" placeholder="BA, PM"></sic-input>
                  </div>

                  <div class="grid grid-cols-3 gap-3 mt-2">
                    <sic-number label="ลำดับ" formControlName="stepOrder" [required]="true" placeholder="1"></sic-number>
                    <sic-number label="Timeout (วัน)" formControlName="timeoutDays" placeholder="3"></sic-number>
                    <div class="flex items-center gap-3 pt-2">
                      <sic-checkbox label="บังคับ" formControlName="isRequired"></sic-checkbox>
                      <sic-checkbox label="ข้ามได้" formControlName="canSkip"></sic-checkbox>
                    </div>
                  </div>

                  <sic-input-area label="Condition Expression" formControlName="conditionExpression" [rows]="1" class="mt-2"></sic-input-area>
                </div>
              }

              @if (steps.length === 0) {
                <div class="text-center py-6 text-[var(--text-muted)] text-sm border border-dashed border-[var(--border)] rounded-lg">
                  ยังไม่มีขั้นตอน คลิก "เพิ่มขั้นตอน" เพื่อเริ่มต้น
                </div>
              }
            </div>
          </div>
        </form>
      </div>

      <div class="px-6 py-4 border-t border-[var(--border)] flex justify-end gap-3 bg-[var(--sidebar)]">
        <sic-button variant="secondary" size="sm" (click)="cancel()">ยกเลิก</sic-button>
        <sic-button variant="primary" size="sm" [disabled]="form.invalid || isSaving()" (click)="save()">
          {{ isSaving() ? 'กำลังบันทึก...' : 'บันทึก' }}
        </sic-button>
      </div>
    </div>
  `,
})
export class Burt06FormComponent implements OnInit {
  @Input() flowId: string | null = null;
  @Input() onSave!: (flow: ApprovalFlow) => void;
  @Input() onCancel!: () => void;

  private fb = inject(FormBuilder);
  private service = inject(Burt06Service);
  private dialog = inject(DialogService);

  isSaving = signal(false);

  documentTypeOptions = DOCUMENT_TYPE_OPTIONS;
  approvalModeOptions = APPROVAL_MODE_OPTIONS;

  form = this.fb.group({
    id: [null],
    flowCode: ['', [Validators.required, Validators.maxLength(50)]],
    flowName: ['', [Validators.required, Validators.maxLength(255)]],
    documentType: ['', [Validators.required]],
    approvalMode: ['CHAIN', [Validators.required]],
    description: [''],
    isActive: [true],
    steps: this.fb.array<FormGroup>([]),
    rowVersion: [null],
  });

  get steps() {
    return this.form.get('steps') as FormArray;
  }

  ngOnInit(): void {
    if (this.flowId) {
      this.service.getFlow(this.flowId).subscribe({
        next: (data) => {
          // ใช้ as any เพื่อ bypass type mismatch
          this.form.patchValue(data as any);
          this.steps.clear();
          data.steps?.forEach((step) => {
            this.steps.push(this.createStepForm(step));
          });
        },
        error: () => this.dialog.error('โหลดข้อมูลไม่สำเร็จ', 'ไม่พบ Flow ที่ต้องการ'),
      });
    } else {
      // เพิ่ม step เริ่มต้น 1 ขั้นตอน
      this.addStep();
    }
  }

  createStepForm(step?: ApprovalFlowStep): FormGroup {
    return this.fb.group({
      id: [step?.id || null],
      stepOrder: [step?.stepOrder || this.steps.length + 1, [Validators.required, Validators.min(1)]],
      stepName: [step?.stepName || '', [Validators.required, Validators.maxLength(255)]],
      approverRole: [step?.approverRole || ''],
      isRequired: [step?.isRequired !== false],
      timeoutDays: [step?.timeoutDays || null],
      canSkip: [step?.canSkip || false],
      conditionExpression: [step?.conditionExpression || ''],
      rowVersion: [step?.rowVersion || null],
    });
  }

  addStep(): void {
    this.steps.push(this.createStepForm());
  }

  removeStep(index: number): void {
    this.steps.removeAt(index);
    // Reorder
    this.steps.controls.forEach((ctrl, i) => {
      ctrl.get('stepOrder')?.setValue(i + 1);
    });
  }

  cancel(): void {
    this.onCancel();
  }

  save(): void {
    if (this.form.invalid) {
      this.form.markAllAsTouched();
      return;
    }

    this.isSaving.set(true);
    const data = this.form.value as ApprovalFlow;

    const request = this.flowId
      ? this.service.updateFlow(this.flowId, data)
      : this.service.createFlow(data);

    request.subscribe({
      next: (result) => {
        this.isSaving.set(false);
        this.onSave(result);
        this.dialog.close(true);
      },
      error: (err) => {
        this.isSaving.set(false);
        this.dialog.error('บันทึกไม่สำเร็จ', err.error?.message || 'เกิดข้อผิดพลาด');
      },
    });
  }
}