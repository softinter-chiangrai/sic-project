import * as i0 from '@angular/core';
import { OnInit, AfterViewInit, OnDestroy, Injector, ChangeDetectorRef, InjectionToken, EnvironmentProviders, OnChanges, AfterContentInit, EventEmitter, QueryList, TemplateRef, SimpleChanges, ElementRef, ComponentRef } from '@angular/core';
import { AbstractControl, ValidationErrors, NgControl, ControlValueAccessor, FormGroup, ValidatorFn, AsyncValidatorFn, FormControl, FormBuilder } from '@angular/forms';
import { CanDeactivateFn } from '@angular/router';
import { Observable } from 'rxjs';
import dayjs, { Dayjs } from 'dayjs';
import { CdkDragDrop } from '@angular/cdk/drag-drop';
import { ComponentType } from '@angular/cdk/overlay';
import { ComponentType as ComponentType$1 } from '@angular/cdk/portal';

declare class SicValidator {
    shouldShowError(control: AbstractControl | null, touched: boolean): boolean;
    resolveErrorMessage(errors: ValidationErrors | null, errorMessages?: Record<string, string>): string | null;
    getErrorMessage(control: AbstractControl | null, errorMessages?: Record<string, string>): string | null;
    getControl(ngControl: NgControl | null): AbstractControl | null;
    isRequired(control: AbstractControl | null): boolean;
    static ɵfac: i0.ɵɵFactoryDeclaration<SicValidator, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<SicValidator>;
}

type SicSize = 'sm' | 'md' | 'lg';
type SicTextAlign = 'left' | 'center' | 'right';
/**
 * Shared ControlValueAccessor plumbing for every sic-ng form control.
 * Mirrors the CVA shape used across sic-app/src/app/core/component (NgControl
 * pulled via Injector in ngOnInit, error state resolved through SicValidator).
 */
declare abstract class SicFormControlBase<T> implements ControlValueAccessor, OnInit, AfterViewInit, OnDestroy {
    size: SicSize;
    label?: string;
    hint?: string;
    disabled: boolean;
    readonly: boolean;
    errorMessages: Record<string, string>;
    get isSm(): boolean;
    get isLg(): boolean;
    get isDisabledHost(): boolean;
    abstract value: T;
    touched: boolean;
    protected readonly injector: Injector;
    protected readonly validator: SicValidator;
    protected readonly cdr: ChangeDetectorRef;
    private ngControl;
    private readonly controlSource;
    /**
     * `markAsTouched()`/`markAllAsTouched()` (e.g. a parent form validating every control before
     * submit) never emits through `statusChanges`/`valueChanges` — Angular only fires those for
     * value/validity changes, not touched/pristine ones. `control.events` is the unified stream that
     * DOES include a `TouchedChangeEvent` for it (alongside status/value/pristine changes).
     * `toSignal()` turns that stream into a signal read from `showError`/`errorMessage` below — no
     * manual `Subscription`/`markForCheck()` needed: Angular's own change-detection scheduler picks
     * up the signal read as a dependency of this component's view and re-checks it on emit, and
     * `toSignal()` unsubscribes by itself via `DestroyRef` when this is destroyed. Without this, an
     * already-rendered control marked touched from the outside stays visually unchanged (no red
     * border/error message) until something unrelated happens to re-run change detection here.
     */
    private readonly controlEvents;
    /**
     * `touched` (below) is this component's own blur-tracked flag — a fallback `shouldShowError` ORs
     * in alongside `control.touched`/`control.dirty`. `markTouched()` only ever sets it to `true`;
     * nothing resets it back to `false` on its own. Every subclass's `writeValue()` override replaces
     * the base implementation entirely (none call `super.writeValue()`), so resetting it there
     * wouldn't reliably run — instead, this effect re-syncs it from the control directly every time
     * `controlEvents` changes (any status/value/touched/pristine event), which reliably fires on
     * `form.reset()`. Without it, a field blurred even once keeps showError permanently gated open:
     * `reset()` correctly clears the *control's* own touched/dirty, but this stale local flag alone
     * would keep forcing showError back to true as soon as the control is invalid again (e.g. a
     * required field reset to empty).
     */
    private readonly syncTouchedFromControl;
    protected onChange: (value: T) => void;
    protected onTouched: () => void;
    ngOnInit(): void;
    ngAfterViewInit(): void;
    ngOnDestroy(): void;
    get control(): AbstractControl<any, any, any> | null;
    get showError(): boolean;
    get errorMessage(): string | null;
    get isRequired(): boolean;
    writeValue(value: T): void;
    registerOnChange(fn: (value: T) => void): void;
    registerOnTouched(fn: () => void): void;
    setDisabledState(isDisabled: boolean): void;
    markTouched(): void;
    /**
     * Commits a new value through the normal CVA `onChange` pipeline, then
     * force-syncs the underlying control's value back out to every accessor
     * bound to it. Angular's forms plumbing deliberately suppresses that
     * model->view echo for the accessor that produced the change (to avoid a
     * feedback loop) — but that also means a second sic-ng control sharing the
     * very same `FormControl` (e.g. a datepicker editing the date portion and a
     * timepicker editing the time portion of one shared `Date`, both wired via
     * `[formControl]`/`formControlName`) would never see the other's update.
     * `emitEvent: false` avoids re-running validation/emitting valueChanges a
     * second time — `onChange` above already did that once.
     */
    protected commitValue(value: T): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<SicFormControlBase<any>, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<SicFormControlBase<any>, never, never, { "size": { "alias": "size"; "required": false; }; "label": { "alias": "label"; "required": false; }; "hint": { "alias": "hint"; "required": false; }; "disabled": { "alias": "disabled"; "required": false; }; "readonly": { "alias": "readonly"; "required": false; }; "errorMessages": { "alias": "errorMessages"; "required": false; }; }, {}, never, never, true, never>;
}

/** One `src` entry within a `SicFontFace` — a single font file plus its CSS format. */
interface SicFontFaceSource {
    /** URL to the font file, e.g. `'/fonts/prompt/Prompt-Regular.ttf'`. */
    url: string;
    /** CSS `format()` value, e.g. `'truetype'`, `'woff2'`. Inferred from the URL's file extension when omitted. */
    format?: string;
}
/**
 * One `@font-face` declaration — typically one per weight/style pair of a custom font, mirroring
 * how variable/static font families ship multiple files (e.g. `Prompt-Regular.ttf` at weight 400,
 * `Prompt-Bold.ttf` at weight 700).
 */
interface SicFontFace {
    /** `font-family` name this rule defines — reference it via `[fontSans]`/`SicThemeConfig.fontSans` (or your own CSS) once registered. */
    family: string;
    /** One or more source files for this family/weight/style combination — multiple entries let the browser pick the first format it supports. */
    sources: SicFontFaceSource[];
    /** Default: `400`. */
    weight?: string | number;
    /** Default: `'normal'`. */
    style?: 'normal' | 'italic' | 'oblique';
    /** Default: `'swap'`. */
    display?: 'auto' | 'block' | 'swap' | 'fallback' | 'optional';
    /** Restricts the rule to a Unicode range, e.g. `'U+0E00-0E7F'` for Thai-only glyphs from a given file. */
    unicodeRange?: string;
}
/**
 * Injects `@font-face` rules for custom/self-hosted fonts (e.g. TTF/WOFF2 files served from your
 * own app, like a Prompt/RobotoCondensed set) into `target` as a single
 * `<style id="sic-ng-custom-fonts">` element — calling again with a new list replaces it entirely
 * rather than duplicating rules. Registering a family doesn't switch anything to it by itself; set
 * `SicThemeConfig.fontSans` (or your own CSS) to actually use it.
 *
 * `target` is the `Document` to inject into — pass `inject(DOCUMENT)` so this stays SSR-safe (no
 * global `document` reference), matching `applySicThemeConfig`'s `target: HTMLElement` pattern.
 */
declare function applySicFontFaces(faces: SicFontFace[], target: Document): void;

type SicThemeMode = 'light' | 'dark' | 'system';
type SicThemeName = 'default' | 'sunset' | 'forest' | 'violet' | 'slate' | 'glass';
declare class SicThemeService {
    private readonly platformId;
    private readonly document;
    readonly mode: i0.WritableSignal<SicThemeMode>;
    readonly isDark: i0.WritableSignal<boolean>;
    readonly themeName: i0.WritableSignal<SicThemeName>;
    private mediaQuery?;
    private mediaQueryHandler?;
    init(defaultMode?: SicThemeMode, defaultThemeName?: SicThemeName): void;
    setThemeName(name: SicThemeName): void;
    private applyThemeName;
    setTheme(mode: SicThemeMode): void;
    toggleDark(): void;
    private applyTheme;
    private bindSystemThemeListener;
    static ɵfac: i0.ɵɵFactoryDeclaration<SicThemeService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<SicThemeService>;
}

interface SicThemeConfig {
    mode?: 'light' | 'dark' | 'system';
    theme?: SicThemeName;
    colorPrimary?: string;
    colorSuccess?: string;
    colorDanger?: string;
    colorWarning?: string;
    radiusSm?: string;
    radiusMd?: string;
    radiusLg?: string;
    /** CSS `font-family` value applied to `--sic-font-sans`, e.g. `'"Prompt", "RobotoCondensed", sans-serif'`. Register the family first via `fonts` if it's a custom/self-hosted font. */
    fontSans?: string;
    /** Custom `@font-face` declarations (e.g. self-hosted TTF/WOFF2 files) to inject before `fontSans` is applied — see `SicFontFace`. */
    fonts?: SicFontFace[];
}
declare const SIC_THEME_CONFIG: InjectionToken<SicThemeConfig>;
/** `target.ownerDocument` — used to inject `config.fonts`' `@font-face` rules, since that needs the `Document`, not just an element. Always set for an element that's part of a live (or SSR-rendered) document tree, which `target` (typically `document.documentElement`) always is. */
declare function applySicThemeConfig(config: SicThemeConfig, target: HTMLElement): void;

declare function provideSicTheme(config?: SicThemeConfig): EnvironmentProviders;

/**
 * Static/bilingual UI text used across components. Any key left unset falls
 * back to that component's built-in English default — set only the ones you
 * need to change.
 */
interface SicMessages {
    /** sic-combobox empty options list. Default: 'No options'. */
    noOptions?: string;
    /** sic-input-comment @mention list when the search returned nothing. Default: 'No matches'. */
    noMatches?: string;
    /** sic-input-comment @mention list while `mentionSearch` is resolving. Default: 'Loading…'. */
    loading?: string;
    /** sic-input-comment attach-file button aria-label. Default: 'Attach file'. */
    attachFile?: string;
    /** sic-input-comment / sic-upload remove-file button aria-label. Default: 'Remove file'. */
    removeFile?: string;
    /** sic-upload drop-zone hint. Default: 'Drag & drop files here, or click to browse'. */
    dragDropHint?: string;
    /** sic-navbar notifications panel empty state. Default: 'No notifications'. */
    noNotifications?: string;
    /** sic-navbar notifications panel footer button. Default: 'View All Notifications'. */
    viewAllNotifications?: string;
    /** sic-calendar agenda/list view empty state. Default: 'No events'. */
    noEvents?: string;
    /** sic-dialog common-dialog Cancel button (confirm() dialogs), unless overridden per-call via `cancelText`. Default: 'Cancel'. */
    cancel?: string;
    /** sic-dialog common-dialog Confirm button (confirm() dialogs), unless overridden per-call via `confirmText`. Default: 'Confirm'. */
    confirm?: string;
    /** sic-dialog common-dialog Close button (info/success/danger/warning dialogs), unless overridden per-call via `closeText`. Default: 'Close'. */
    close?: string;
    /** sic-gridpanel initial-load state. Default: 'Loading...'. */
    gridLoading?: string;
    /** sic-gridpanel busy overlay while a save is in flight. Default: 'Saving data...'. */
    gridSaving?: string;
    /** sic-gridpanel busy overlay while data is (re)loading. Default: 'Loading data...'. */
    gridLoadingOverlay?: string;
    /** sic-gridpanel empty state title with no rows. Default: 'No data found'. */
    gridNoData?: string;
    /** sic-gridpanel empty state title in review-changes mode with nothing changed. Default: 'No changed data'. */
    gridNoChangedData?: string;
    /** sic-gridpanel empty state subtitle with no rows. Default: 'Try adjusting your search or add a new row.'. */
    gridNoDataHint?: string;
    /** sic-gridpanel empty state subtitle in review-changes mode with nothing changed. Default: 'Try turning off review mode to see all rows.'. */
    gridNoChangedDataHint?: string;
    /** Suffix appended after the number in sic-gridpanel's page-size dropdown (e.g. "10" + suffix). Default: '' (no suffix). */
    gridPageSizeSuffix?: string;
    /** sic-search empty result list. Default: 'No results'. */
    noResults?: string;
    /** sic-masonry empty state when `items`/the loaded pages are empty. Default: 'No items'. */
    noItems?: string;
    /** sic-masonry indicator shown under the grid while `isLazy` is fetching the next page. Default: 'Loading more...'. */
    masonryLoading?: string;
    /** sic-drag-drop placeholder text shown inside an empty list/column. Default: 'Drop items here'. */
    dragDropEmptyList?: string;
    /** sic-stepper built-in nav "Previous" button. Default: 'Previous'. */
    stepperPrevious?: string;
    /** sic-stepper built-in nav "Next" button. Default: 'Next'. */
    stepperNext?: string;
    /** sic-stepper built-in nav "Skip" button, shown only on optional steps. Default: 'Skip'. */
    stepperSkip?: string;
    /** sic-stepper built-in nav "Finish" button, shown on the last step. Default: 'Finish'. */
    stepperFinish?: string;
    /** sic-code copy button, idle state. Default: 'Copy'. */
    codeCopy?: string;
    /** sic-code copy button, briefly shown right after a successful copy. Default: 'Copied'. */
    codeCopied?: string;
    /** sic-calendar-timeline view-mode switcher label. Default: 'View'. */
    calendarTimelineViewLabel?: string;
    /** sic-calendar-timeline view-mode switcher "day" option. Default: 'Day'. */
    calendarTimelineDay?: string;
    /** sic-calendar-timeline view-mode switcher "week" option. Default: 'Week'. */
    calendarTimelineWeek?: string;
    /** sic-calendar-timeline view-mode switcher "month" option. Default: 'Month'. */
    calendarTimelineMonth?: string;
    /** sic-video-player play-button overlay aria-label, shown over the poster before playback starts. Default: 'Play video'. */
    playVideo?: string;
    /** sicCanDeactivateGuard's confirm-dialog title when the leaving component reports unsaved changes. Default: 'Unsaved changes'. */
    unsavedChangesTitle?: string;
    /** sicCanDeactivateGuard's confirm-dialog description. Default: 'You have unsaved changes. Leave this page anyway?'. */
    unsavedChangesMessage?: string;
}
/** Library-wide defaults, set once via `provideSicConfig()`. Any per-component `@Input` still wins over these. */
interface SicConfig {
    /** Default decimal places for sic-input-number and sic-gridpanel's `number` columns/summaries. Default: 2. */
    decimals?: number;
    /** Default display format for sic-datepicker and sic-gridpanel's `date` columns. Default: 'dd/MM/yyyy'. */
    dateFormat?: string;
    /** Default year numbering for sic-datepicker/sic-calendar — 'CE' (Gregorian) or 'BE' (Buddhist, ค.ศ. + 543). Default: 'CE'. */
    era?: 'BE' | 'CE';
    /** Default dayjs locale code for sic-datepicker/sic-calendar. Default: 'en'. */
    locale?: string;
    /** Default image URL (.png/.gif/etc.) shown by `SicLoadingService.show()` when the caller doesn't pass its own `image`. Unset falls back to the sic-spinner. */
    loadingImage?: string;
    /** Default spinner size for `SicLoadingService.show()` when no image and no explicit `spinnerSize` are given. Default: 'lg'. */
    loadingSpinnerSize?: 'sm' | 'md' | 'lg';
    /** Default max upload size (MB) for sic-upload and sic-input-comment. Default: 10. */
    maxUploadSizeMb?: number;
    /** Default page size for sic-gridpanel and sic-combobox paging. Default: 10. */
    pageSize?: number;
    /** Default page-size choices for sic-gridpanel. Default: [10, 30, 50]. */
    pageSizeOptions?: number[];
    messages?: SicMessages;
}
declare const SIC_CONFIG: InjectionToken<SicConfig>;
/** Registers library-wide defaults. Call once alongside `provideSicTheme()` in `bootstrapApplication`/`ApplicationConfig`. */
declare function provideSicConfig(config: SicConfig): EnvironmentProviders;
/** Components call this instead of `inject(SIC_CONFIG, { optional: true })` directly — always returns an object, never null. */
declare function injectSicConfig(): SicConfig;

/**
 * Tracks a row/entity's relationship to its persisted source, mirroring the
 * EF Core `EntityState` names so backend/frontend state vocab stays aligned
 * across a save-changes payload.
 */
declare const SicEntityState: {
    /** Not tracked for change-detection at all (e.g. the row was removed from its parent list/grid). */
    readonly Detached: "detached";
    /** Matches the last-known-saved baseline — no pending changes. */
    readonly Unchanged: "unchanged";
    /** New row not yet persisted. */
    readonly Added: "added";
    /** Differs from the last-known-saved baseline. */
    readonly Modified: "modified";
    /** Marked for deletion on next save. */
    readonly Deleted: "deleted";
};
type SicEntityState = (typeof SicEntityState)[keyof typeof SicEntityState];

type SicStateModel = {
    state?: SicEntityState | null;
};
/**
 * Wraps a row's `FormGroup` with EF-Core-style change tracking (`SicEntityState`),
 * for building an "editable grid" where each row needs to report whether it's
 * new/edited/deleted before a bulk save.
 */
declare class SicFormData<TModel extends object & SicStateModel> {
    private readonly sourceFormGroup;
    private initialModel;
    private initialComparableValue;
    private readonly subscription;
    private currentState;
    private readonly includesStateInValue;
    constructor(sourceFormGroup: FormGroup, model?: TModel);
    get isChanged(): boolean;
    get isNotChanged(): boolean;
    get state(): SicEntityState;
    get formGroup(): FormGroup;
    get invalid(): boolean;
    get valid(): boolean;
    get value(): TModel;
    delete(): void;
    /**
     * Discards any unsaved edits by patching the form's values back to the last-known-saved
     * baseline (the model this `SicFormData` was constructed/last `markAsPristine()`d with), then
     * re-derives state from that — which also reverses a pending `delete()`, since the row's value
     * no longer differs from its baseline. Works regardless of the row's current state, except a
     * still-`Added` (never-saved) row, which stays `Added` — reverted back to blank, it's still a
     * pending new row, not a persisted-and-unchanged one.
     */
    restore(): void;
    /** Clears every control back to its own default value (e.g. `fb.control(null)` → `null`) and
     * marks the form pristine/untouched — for starting a brand-new blank entry. State is then
     * re-derived reactively from the resulting (blank) value, same as any other edit. */
    reset(): void;
    markAllAsTouched(): void;
    /**
     * Call after a successful save: resets Angular's own `dirty` flag AND
     * re-baselines both the comparable value used for dirty-checking and `restore()`'s target
     * value to the row's current (just-saved) value — without this, editing the row again
     * afterwards (or calling `restore()`) would keep comparing/reverting against the value from
     * when this `SicFormData` was first constructed, not the value that was actually saved.
     */
    markAsPristine(): void;
    destroy(): void;
    get dirty(): boolean;
    private syncStateFromForm;
    private applyComparableState;
    private resolveInitialState;
    private writeState;
    private toComparableValue;
    private cloneValue;
    private cloneFallback;
    private isEqual;
}

interface SicRadioOption {
    value: unknown;
    name: string;
}
type SicRadioDirection = 'row' | 'column';
declare class SicRadioComponent extends SicFormControlBase<unknown> {
    name: string;
    radioValue: unknown;
    options: SicRadioOption[];
    direction: SicRadioDirection;
    readonly hostClass = true;
    get isGroup(): boolean;
    value: unknown;
    get checked(): boolean;
    isChecked(optionValue: unknown): boolean;
    onRadioChange(nextValue?: unknown): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<SicRadioComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<SicRadioComponent, "sic-radio", never, { "name": { "alias": "name"; "required": false; }; "radioValue": { "alias": "radioValue"; "required": false; }; "options": { "alias": "options"; "required": false; }; "direction": { "alias": "direction"; "required": false; }; }, {}, never, never, true, never>;
}

type SicGridPanelTemplateSection = 'cell' | 'header' | 'footer';
interface SicGridOption {
    label: string;
    value: unknown;
}
interface SicGridColumnAction {
    name: string;
    label: string;
    variant?: 'default' | 'danger' | 'ghost';
}
interface SicGridColumnConfig {
    label: string;
    name: string;
    type: string;
    editable?: boolean;
    sortable?: boolean;
    /** Horizontal alignment of the cell's content. Defaults to 'right' for number columns, 'left' otherwise. */
    align?: 'left' | 'center' | 'right';
    width?: number;
    /** Floor for the column's width (px) — applies both when columns fit and shrink proportionally, and when they overflow to fixed widths. */
    minWidth?: number;
    placeholder?: string;
    hidden?: boolean;
    options?: SicGridOption[];
    checkedValue?: unknown;
    uncheckedValue?: unknown;
    rows?: number;
    direction?: 'row' | 'column';
    dateFormat?: string;
    clearable?: boolean;
    minDate?: string;
    maxDate?: string;
    decimals?: number;
    accept?: string;
    multiple?: boolean;
    maxSizeMb?: number;
    hint?: string;
    validator?: ValidatorFn | ValidatorFn[] | null;
    validators?: ValidatorFn | ValidatorFn[] | null;
    asyncValidator?: AsyncValidatorFn | AsyncValidatorFn[] | null;
    asyncValidators?: AsyncValidatorFn | AsyncValidatorFn[] | null;
    errorMessages?: Record<string, string>;
    buttonText?: string;
    actions?: SicGridColumnAction[];
    footerText?: string;
    customTemplate?: string;
}
/** Groups several columns under one shared label spanning a second header row above them. */
interface SicGridColumnGroupConfig {
    label: string;
    /** `column.name`s covered by this group — must be contiguous among the currently visible columns. */
    columns: string[];
    align?: 'left' | 'center' | 'right';
}
interface SicGridToolbarConfig {
    /** Save-changes button. Default true. */
    save?: boolean;
    /** Add-row button. Default true. */
    add?: boolean;
    /** Delete-selected-rows button. Default true. */
    delete?: boolean;
    /** Review-changed-rows toggle button. Default true. */
    review?: boolean;
}
type SicGridSummaryType = 'sum' | 'avg' | 'count' | 'min' | 'max' | 'custom';
interface SicGridSummaryConfig {
    /** Column name this summary is rendered under, in the footer row. */
    column: string;
    type: SicGridSummaryType;
    label?: string;
    /** Only used as a fallback when `column.type` isn't 'number' (or type is 'custom' on a non-number column) — a 'number' column's own `decimals` wins otherwise, so the summary always matches how the column itself formats its values. Ignored for type 'count' (always a plain integer). */
    decimals?: number;
    /** Defaults to 'right' for number columns, 'left' otherwise. */
    align?: 'left' | 'center' | 'right';
    /** Required when type is 'custom'; the raw number fed into `formatter`. */
    calculate?: (rows: SicGridRowData[]) => number;
    formatter?: (value: number, rows: SicGridRowData[]) => string;
}
interface SicGridGrandSummaryConfig {
    /** 'all' (default): render the grand-total row on every page. 'last': only on the final page. */
    showOn?: 'all' | 'last';
    columns: SicGridSummaryConfig[];
}
interface SicGridPanelConfig {
    id: string;
    defaultSortField?: string;
    defaultSortDescending?: boolean;
    pageable?: boolean;
    /** Show the row-selection checkbox column (header "select all" + per-row). Default true. */
    selectable?: boolean;
    /**
     * true (default): every page/sort/keyword change re-emits `(loadData)` —
     * the host fetches just that page from the server.
     * false: `(loadData)` fires once (plus explicit `reload()`); the host
     * hands back the *entire* dataset via `setRows()` and the grid sorts and
     * paginates it locally without further round-trips.
     */
    lazy?: boolean;
    pageNumber?: number;
    pageSize?: number;
    /** Options offered by the footer's page-size dropdown. Default [10, 30, 50]. */
    pageSizeOptions?: number[];
    /** Show the footer's page-size dropdown (when `pageable` is also on). Default true. */
    pageSizeSelector?: boolean;
    keyword?: string;
    params?: Record<string, unknown>;
    disableRow?: (row: SicGridRowData) => boolean;
    /** Return true to disable the row's selection checkbox — independent of `disableRow`. */
    disableSelect?: (rowIndex: number, rowData: SicGridRowData) => boolean;
    /** Called per editable cell — return true to make that field (or, if the callback ignores fieldName, the whole row) readonly. */
    disableEdit?: (rowIndex: number, fieldName: string, data: unknown, rowData: SicGridRowData) => boolean;
    createRowValue?: Record<string, unknown> | (() => Record<string, unknown>);
    column?: SicGridColumnConfig[];
    columns?: SicGridColumnConfig[];
    /** Optional — groups columns under a shared label on a second header row above them (e.g. "Info" spanning Age/Visits/Status). Omit for the regular single-row header. */
    columnGroups?: SicGridColumnGroupConfig[];
    /** Aggregated values rendered on their own footer row, per column, computed from just the currently-displayed page. */
    summaryPage?: SicGridSummaryConfig[];
    /**
     * Aggregated values rendered on a second footer row (below summaryPage's,
     * if present), computed from the *entire* dataset rather than just the
     * current page — in `lazy: false` mode that's genuinely every row; in
     * `lazy: true` mode it's limited to whatever pages the grid has already
     * loaded, since the client never holds the full server-side dataset at once.
     */
    summary?: SicGridGrandSummaryConfig;
    /** Show/hide individual toolbar buttons. Every button defaults to visible. */
    toolbar?: SicGridToolbarConfig;
    /** Show/hide the entire toolbar bar (save/add/delete/review buttons), regardless of the individual `toolbar` flags. Default true. */
    showToolbar?: boolean;
    /** Show/hide the entire footer bar (page-size dropdown, "Total N rows", pager), regardless of `pageable`/`pageSizeSelector`. Default true. */
    showFooterBar?: boolean;
}
interface SicGridLoadRequest {
    requestId: number;
    pageNumber: number;
    pageSize: number;
    sortField: string | null;
    sortDescending: boolean;
    keyword: string | null;
    params: Record<string, unknown> | null;
}
interface SicGridSaveRequest {
    requestId: number;
    rows: unknown[];
}
interface SicGridPagingState {
    pageNumber?: number;
    pageSize?: number;
    totalElements?: number;
    totalPages?: number;
}
type SicGridPagerItem = number | 'start-ellipsis' | 'end-ellipsis';
type SicGridRowState = 'active' | 'new' | 'updated' | 'deleted';
type SicGridRowData = Record<string, unknown>;
declare class SicGridPanelTemplate {
    readonly template: TemplateRef<unknown>;
    name: string;
    section: SicGridPanelTemplateSection;
    constructor(template: TemplateRef<unknown>);
    static ɵfac: i0.ɵɵFactoryDeclaration<SicGridPanelTemplate, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<SicGridPanelTemplate, "ng-template[sicGridPanelTemplate]", never, { "name": { "alias": "sicGridPanelTemplate"; "required": false; }; "section": { "alias": "section"; "required": false; }; }, {}, never, never, true, never>;
}
declare class SicGridPanelComponent implements OnChanges, AfterContentInit, AfterViewInit, OnDestroy {
    private readonly sicConfig;
    config: SicGridPanelConfig;
    readonly loadData: EventEmitter<SicGridLoadRequest>;
    readonly saveData: EventEmitter<SicGridSaveRequest>;
    readonly rowsChange: EventEmitter<SicGridRowData[]>;
    readonly rowAction: EventEmitter<{
        action: string;
        row?: SicGridRowData | null;
        rows?: SicGridRowData[];
        column?: SicGridColumnConfig | null;
    }>;
    readonly softDeleteChange: EventEmitter<{
        id: unknown;
        deleted: boolean;
        row: SicGridRowData;
    }>;
    readonly hostClass = true;
    templates?: QueryList<SicGridPanelTemplate>;
    private readonly surfaceRef?;
    readonly rows: SicGridRowData[];
    readonly deletedRowIds: Set<string>;
    readonly selectedRowIds: Set<string>;
    loading: boolean;
    saving: boolean;
    reviewChangesOnly: boolean;
    currentPage: number;
    pageSize: number;
    totalElements: number;
    totalPages: number;
    sortField: string | null;
    sortDescending: boolean;
    gridTemplateColumns: string;
    /** True when columns use fixed pixel widths that may exceed the host width (needs horizontal
     * scroll) — false when columns are proportional (`calc(% ...)`) and stretch to fill the host.
     * Drives whether the header/row grids are `width: max-content` or `width: 100%`; mixing
     * `max-content` with percentage-based tracks makes each row's rendered column widths follow
     * that row's own content instead of a shared width, desyncing header and body columns. */
    gridColumnsFixedWidth: boolean;
    private readonly controlMap;
    private readonly controlSubscriptions;
    private readonly controlStateMap;
    private readonly selectionControlMap;
    private readonly selectionSubscriptions;
    private readonly originalRowSnapshots;
    private readonly localAddedRows;
    private readonly localUpdatedRows;
    private readonly comboboxOptionsCache;
    private readonly radioOptionsCache;
    private readonly rowKeys;
    private readonly cdr;
    private readonly datePipe;
    private readonly toastService;
    private templatesReady;
    private rowKeySequence;
    private pageBeforeReviewChanges;
    private latestServerRows;
    private serverTotalElements;
    private syncingSelectionState;
    private validationRequested;
    private loadRequestId;
    private pendingLoadRequestId;
    private saveRequestId;
    private pendingSaveRequestId;
    private pendingSaveTrackedRows;
    readonly selectAllControl: FormControl<boolean | null>;
    private readonly selectAllSubscription;
    readonly pageSizeControl: FormControl<number | null>;
    private syncingPageSize;
    private readonly pageSizeSubscription;
    private visibleColumnsCache;
    get visibleColumns(): SicGridColumnConfig[];
    get hasColumnGroups(): boolean;
    get visibleColumnGroups(): SicGridColumnGroupConfig[];
    /** True if `column` is covered by one of `config.columnGroups`. */
    isColumnGrouped(column: SicGridColumnConfig): boolean;
    /**
     * CSS grid-column line range for a single header cell — line 1 is the
     * selection column, so a visible column at index `i` occupies lines
     * `i + 2` to `i + 3`.
     */
    getColumnGridColumn(column: SicGridColumnConfig): string;
    /** CSS grid-column line range spanning every (visible) member column of a group. */
    getGroupGridColumn(group: SicGridColumnGroupConfig): string;
    get hasFooter(): boolean;
    get showPager(): boolean;
    get showPageSizeSelector(): boolean;
    /** The configured options, plus the current `pageSize` itself if it isn't already one of them. */
    get pageSizeOptions(): number[];
    get pageSizeSelectOptions(): {
        label: string;
        value: number;
    }[];
    get loadingText(): string;
    get noDataTitle(): string;
    get noDataSubtitle(): string;
    get busyText(): string;
    get isLazy(): boolean;
    get hasPendingChanges(): boolean;
    get canSaveChanges(): boolean;
    get showSaveButton(): boolean;
    get showAddButton(): boolean;
    get showSelectionColumn(): boolean;
    get showDeleteButton(): boolean;
    get showReviewButton(): boolean;
    get hasVisibleToolbarButtons(): boolean;
    get showFooterBar(): boolean;
    get isBusy(): boolean;
    get changedRowsCount(): number;
    get canReviewChanges(): boolean;
    get pagerItems(): SicGridPagerItem[];
    get selectedRows(): SicGridRowData[];
    get selectedCount(): number;
    get canDeleteSelected(): boolean;
    get selectableCount(): number;
    get deletedCount(): number;
    get newCount(): number;
    get updatedCount(): number;
    ngOnChanges(changes: SimpleChanges): void;
    ngAfterContentInit(): void;
    ngAfterViewInit(): void;
    ngOnDestroy(): void;
    handleWindowResize(): void;
    /** Ask the host application to (re)fetch the current page; listen on `(loadData)`. */
    reload(): void;
    /** Host calls this once its fetch triggered by `(loadData)` resolves. */
    setRows(data: SicGridRowData[], pageable?: SicGridPagingState, requestId?: number): void;
    /** Host calls this if its fetch triggered by `(loadData)` fails. */
    setLoadError(message: string, requestId?: number): void;
    /** Host calls this once its persist triggered by `(saveData)` resolves. */
    setSaveResult(success: boolean, message?: string, requestId?: number): void;
    addRow(): void;
    toggleReviewChanges(): void;
    saveChanges(): void;
    /** True if any tracked new/updated row is currently invalid — mirrors `SicFormData.invalid`, so both can be checked the same way from `sicFormCombine()`. */
    get invalid(): boolean;
    get valid(): boolean;
    /** Touches every tracked new/updated row's controls, so invalid ones show their error state — mirrors `SicFormData.markAllAsTouched()`. */
    markAllAsTouched(): void;
    /**
     * Touches every tracked row's controls and reports whether they're all valid —
     * without saving. Useful for validating several forms/grids together before a
     * combined submit, e.g. via `sicFormCombine()`.
     */
    validate(): boolean;
    /**
     * Reverts every pending new/updated/deleted row back to its last-known baseline
     * (also undoes a pending delete) — mirrors `SicFormData.restore()`. A brand-new
     * (never-saved) row has no baseline to revert to, so it's left as-is, same as
     * `SicFormData.restore()` leaving an `Added` row `Added`.
     */
    restore(): void;
    /** Discards every pending change, including brand-new rows — mirrors `SicFormData.reset()`. */
    reset(): void;
    /** The pending new/updated/deleted rows, in save order, as the same payload shape `(saveData)` receives — without triggering a save. */
    getChangedRowsPayload(): unknown[];
    private getRowsToPersist;
    deleteSelectedRows(): void;
    sortBy(column: SicGridColumnConfig): void;
    goToPreviousPage(): void;
    goToNextPage(): void;
    goToPage(page: number): void;
    changePageSize(size: number): void;
    private syncPageSizeControl;
    isRowDeleted(row: any): boolean;
    isRowDisabled(row: SicGridRowData): boolean;
    isRowSelectDisabled(row: SicGridRowData, rowIndex: number): boolean;
    isRowSelected(row: any): boolean;
    canResetRow(row: SicGridRowData): boolean;
    isRowEditable(row: any): boolean;
    isCellEditable(row: any, column: SicGridColumnConfig): boolean;
    shouldRenderCellField(row: any, column: SicGridColumnConfig): boolean;
    isCellReadonly(row: any, column: SicGridColumnConfig, rowIndex: number): boolean;
    getRowState(row: any): SicGridRowState;
    toggleSoftDelete(row: any, column: SicGridColumnConfig): void;
    triggerRowAction(action: SicGridColumnAction, row: any, column: SicGridColumnConfig): void;
    handleValueChange(row: any, column: SicGridColumnConfig, rawValue: unknown): void;
    resetRow(row: SicGridRowData): void;
    trackRow: (_index: number, row: any) => string;
    trackColumn: (_index: number, column: SicGridColumnConfig) => string;
    formatCellValue(row: any, column: SicGridColumnConfig): string;
    private formatNumber;
    getCellTemplate(column: SicGridColumnConfig): TemplateRef<unknown> | null;
    getHeaderTemplate(column: SicGridColumnConfig): TemplateRef<unknown> | null;
    getFooterTemplate(column: SicGridColumnConfig): TemplateRef<unknown> | null;
    isBuiltInType(type: string): boolean;
    isSortedAsc(column: SicGridColumnConfig): boolean;
    isSortedDesc(column: SicGridColumnConfig): boolean;
    hasSummary(column: SicGridColumnConfig): boolean;
    /** Aggregates `this.rows` (the currently loaded page) per `config.summaryPage`. */
    getSummaryText(column: SicGridColumnConfig): string | null;
    getSummaryAlign(column: SicGridColumnConfig): 'left' | 'center' | 'right';
    get hasGrandSummary(): boolean;
    /**
     * Rows the grid actually holds — the full dataset in `lazy: false` mode,
     * or just the pages fetched so far in `lazy: true` mode (see the
     * `summary` doc comment on SicGridPanelConfig for why that's the ceiling).
     */
    private get knownRows();
    get showGrandSummaryRow(): boolean;
    hasGrandSummaryColumn(column: SicGridColumnConfig): boolean;
    /** Aggregates `knownRows` (see above) per `config.summary.columns`. */
    getGrandSummaryText(column: SicGridColumnConfig): string | null;
    getGrandSummaryAlign(column: SicGridColumnConfig): 'left' | 'center' | 'right';
    private resolveSummaryAlign;
    private formatSummaryValue;
    private calculateSummaryValue;
    getControl(row: any, column: SicGridColumnConfig, rowIndex: number): FormControl;
    getSelectionControl(row: any, rowIndex: number): FormControl;
    toRadioOptions(column: SicGridColumnConfig): SicRadioOption[];
    getRadioOptions(column: SicGridColumnConfig): SicRadioOption[];
    getComboboxOptions(column: SicGridColumnConfig): SicGridOption[];
    protected resolveTemplateName(column: SicGridColumnConfig): string;
    private requestLoad;
    private applyDefaultSort;
    private touchVisibleControls;
    /**
     * `controlMap` only holds FormControls for rows on the current page/mode —
     * seed `controlStateMap` (touched) for editable columns of every other
     * tracked new/updated row too, so once that row is rendered later (page
     * change, review-changes toggle, etc.) `getControl()` reconstructs it
     * already touched and its red-border/error state shows immediately.
     */
    private touchOffScreenTrackedRows;
    private captureCurrentControlStates;
    private isEditableColumn;
    private getRowsNeedingValidation;
    /** Checks currently-rendered controls plus tracked rows that aren't on this page/mode right now. */
    private hasInvalidTrackedRows;
    private buildSavePayload;
    private toEntityState;
    private getPersistPriority;
    private resolveValidators;
    private resolveAsyncValidators;
    private normalizeValidatorFns;
    private updateGridTemplateColumns;
    private getFallbackHostWidth;
    protected resolveColumnWidth(column: SicGridColumnConfig): number;
    private findTemplate;
    private resolveOptionLabel;
    private coerceValue;
    private rebuildControls;
    private rebuildSelectionControls;
    private syncControlValue;
    private disposeControls;
    private disposeSelectionControls;
    private toggleSelectAll;
    private syncSelectAllState;
    private syncSelectAllControlDisabledState;
    private syncSelectionControlValue;
    private syncSelectionControlDisabledState;
    private syncControlDisabledState;
    private appendNewRow;
    private createEmptyRow;
    private getControlKey;
    private getRowValue;
    private getRowKey;
    private captureOriginalSnapshots;
    private refreshVisibleRows;
    private moveToPreviousPageIfEmpty;
    private resolveLocalRowsForCurrentPage;
    private resolveCombinedTotalPages;
    private resetTrackedStateAfterSave;
    private isLocalAddedRow;
    private removeLocalAddedRows;
    private persistRowChange;
    private refreshRowsForCurrentMode;
    private refreshRowsAfterTrackingChange;
    private hasRowChanged;
    private serializeComparableRow;
    private toSerializableRow;
    private getTrackedRows;
    private getChangedRows;
    private getSortedChangedRows;
    private sortRows;
    private compareSortValues;
    private isEmptySortValue;
    private normalizeSortValue;
    private resolveReviewTotalPages;
    private resolveReviewTargetPage;
    private serializeRows;
    static ɵfac: i0.ɵɵFactoryDeclaration<SicGridPanelComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<SicGridPanelComponent, "sic-gridpanel", never, { "config": { "alias": "config"; "required": true; }; }, { "loadData": "loadData"; "saveData": "saveData"; "rowsChange": "rowsChange"; "rowAction": "rowAction"; "softDeleteChange": "softDeleteChange"; }, ["templates"], never, true, never>;
}

type SicFormCombineSource = SicFormData<any> | SicGridPanelComponent;
interface SicFormCombineResult<TValue = Record<string, unknown>> {
    /** True only if every source is currently valid. Read live — reflects edits made after `sicFormCombine()` was called. */
    readonly valid: boolean;
    readonly invalid: boolean;
    /** One key per entry of `sources`: a `SicFormData`'s `.value`, or a grid's pending new/updated/deleted rows via `getChangedRowsPayload()`. Read live. */
    readonly value: TValue;
    /** Touches every source's controls, so invalid fields/rows show their error state — proxies to each source's own `markAllAsTouched()`. */
    markAllAsTouched(): void;
    /** Reverts every source back to its last-known baseline — proxies to each source's own `restore()`. */
    restore(): void;
    /** Clears every source back to blank/pristine — proxies to each source's own `reset()`. */
    reset(): void;
}
/**
 * Combines several `SicFormData` instances and/or `SicGridPanelComponent`s
 * (e.g. one form plus multiple editable grids on the same page) into a single
 * result — for validating and submitting them together as one JSON payload.
 */
declare function sicFormCombine<TValue = Record<string, unknown>>(sources: Record<string, SicFormCombineSource>): SicFormCombineResult<TValue>;

/**
 * Maps a flat model to its `FormGroup` controls shape, e.g. for
 * `new FormGroup<ToForm<TModel>>({ ... })`.
 *
 * - `-?` drops the source model's own optional (`?:`) modifier: an optional
 *   *field* on the model must not become an optional *control* on the form —
 *   the control should always exist, only its value may be `null`/unset.
 * - Only for flat models. A nested object/array field maps to a single
 *   `FormControl` holding that whole value, not a nested `FormGroup`/`FormArray`.
 */
type ToForm<T extends object> = {
    [K in keyof T]-?: FormControl<T[K] | null>;
};
/**
 * Builds a `FormGroup<ToForm<TModel>>` for a `SicStateModel`-based model from just its domain
 * field controls — `state` is appended automatically, so a form definition never has to repeat
 * `state: fb.control(...)` by hand (and can't forget it, unlike `SicFormData`'s own defensive
 * fallback for a form built without one).
 */
declare function createSicFormGroup<TModel extends SicStateModel>(fb: FormBuilder, controls: ToForm<Omit<TModel, 'state'>>): FormGroup<ToForm<TModel>>;

/** Implement on any routed component to opt into `sicCanDeactivateGuard`'s unsaved-changes prompt. */
interface SicCanComponentDeactivate {
    /** Return true while the page has unsaved changes the user could lose by navigating away. */
    pageDirty(): boolean;
}
/**
 * Route `data` key a *target* route can set to `true` to skip the confirm prompt for that
 * navigation — e.g. a session-expired or logout redirect the app itself triggers, which has no
 * user present to answer a "leave page?" dialog: `{ path: 'login', data: { [SIC_SKIP_DEACTIVATE_GUARD]: true } }`.
 */
declare const SIC_SKIP_DEACTIVATE_GUARD = "skipDeactivateGuard";
/**
 * `canDeactivate` guard: prompts to confirm leaving (via `SicDialogService.confirm()`) only when
 * the component being left reports unsaved changes through `SicCanComponentDeactivate.pageDirty()`.
 *
 * This only intercepts in-app Angular Router navigation — a browser tab close/refresh bypasses it
 * entirely. Pair it with `sicWarnBeforeUnload()` in the same component to also cover that case.
 *
 * ```ts
 * // profile.routes.ts
 * {
 *   path: 'profile',
 *   loadComponent: () => import('./management/profile/profile.component').then((m) => m.Profile),
 *   resolve: { form: profileResolver },
 *   canDeactivate: [sicCanDeactivateGuard],
 * }
 *
 * // profile.component.ts
 * export class Profile implements SicCanComponentDeactivate {
 *   // ...
 *   pageDirty(): boolean {
 *     return this.formProfileData.dirty; // SicFormData already tracks this
 *   }
 * }
 * ```
 */
declare const sicCanDeactivateGuard: CanDeactivateFn<SicCanComponentDeactivate>;

/**
 * Warns on a browser tab close/refresh (the native `beforeunload` prompt) whenever `isDirty()`
 * returns true — the one "leave the page" path `sicCanDeactivateGuard` can't intercept, since that
 * guard only runs for in-app Angular Router navigation.
 *
 * Call once from a routed page component's constructor (or any injection context) — it removes
 * its own listener on destroy via `DestroyRef`, no manual cleanup needed. No-op outside the
 * browser (SSR).
 */
declare function sicWarnBeforeUnload(isDirty: () => boolean): void;

type SicInputType = 'text' | 'email' | 'password' | 'search' | 'tel' | 'url';
declare class SicInputComponent extends SicFormControlBase<string> {
    name?: string;
    placeholder: string;
    type: SicInputType;
    autocomplete?: string;
    maxlength?: number;
    align: SicTextAlign;
    readonly hostClass = true;
    get isAlignCenter(): boolean;
    get isAlignRight(): boolean;
    value: string;
    writeValue(value: string | null | undefined): void;
    handleInput(event: Event): void;
    handleBlur(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<SicInputComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<SicInputComponent, "sic-input", never, { "name": { "alias": "name"; "required": false; }; "placeholder": { "alias": "placeholder"; "required": false; }; "type": { "alias": "type"; "required": false; }; "autocomplete": { "alias": "autocomplete"; "required": false; }; "maxlength": { "alias": "maxlength"; "required": false; }; "align": { "alias": "align"; "required": false; }; }, {}, never, never, true, never>;
}

declare class SicInputPasswordComponent extends SicFormControlBase<string> {
    name?: string;
    placeholder: string;
    autocomplete: string;
    align: SicTextAlign;
    readonly hostClass = true;
    get isAlignCenter(): boolean;
    get isAlignRight(): boolean;
    value: string;
    revealed: boolean;
    writeValue(value: string | null | undefined): void;
    toggleReveal(): void;
    handleInput(event: Event): void;
    handleBlur(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<SicInputPasswordComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<SicInputPasswordComponent, "sic-input-password", never, { "name": { "alias": "name"; "required": false; }; "placeholder": { "alias": "placeholder"; "required": false; }; "autocomplete": { "alias": "autocomplete"; "required": false; }; "align": { "alias": "align"; "required": false; }; }, {}, never, never, true, never>;
}

declare class SicInputNumberComponent extends SicFormControlBase<number | null> {
    private readonly sicConfig;
    name?: string;
    placeholder: string;
    min?: number;
    max?: number;
    prefix: string;
    suffix: string;
    align: SicTextAlign;
    decimals: number;
    thousandSeparator: string;
    decimalSeparator: string;
    readonly hostClass = true;
    get isAlignCenter(): boolean;
    get isAlignRight(): boolean;
    value: number | null;
    private focused;
    private rawValue;
    get displayValue(): string;
    writeValue(value: number | null | undefined): void;
    handleFocus(): void;
    handleInput(event: Event): void;
    handleBlur(): void;
    private clamp;
    private roundToDecimals;
    private toEditableString;
    private formatNumber;
    private parseInput;
    static ɵfac: i0.ɵɵFactoryDeclaration<SicInputNumberComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<SicInputNumberComponent, "sic-input-number", never, { "name": { "alias": "name"; "required": false; }; "placeholder": { "alias": "placeholder"; "required": false; }; "min": { "alias": "min"; "required": false; }; "max": { "alias": "max"; "required": false; }; "prefix": { "alias": "prefix"; "required": false; }; "suffix": { "alias": "suffix"; "required": false; }; "align": { "alias": "align"; "required": false; }; "decimals": { "alias": "decimals"; "required": false; }; "thousandSeparator": { "alias": "thousandSeparator"; "required": false; }; "decimalSeparator": { "alias": "decimalSeparator"; "required": false; }; }, {}, never, never, true, never>;
}

declare class SicInputAreaComponent extends SicFormControlBase<string> {
    name?: string;
    placeholder: string;
    rows: number;
    maxlength?: number;
    autoResize: boolean;
    align: SicTextAlign;
    readonly hostClass = true;
    get isAlignCenter(): boolean;
    get isAlignRight(): boolean;
    value: string;
    writeValue(value: string | null | undefined): void;
    handleInput(event: Event): void;
    handleBlur(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<SicInputAreaComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<SicInputAreaComponent, "sic-input-area", never, { "name": { "alias": "name"; "required": false; }; "placeholder": { "alias": "placeholder"; "required": false; }; "rows": { "alias": "rows"; "required": false; }; "maxlength": { "alias": "maxlength"; "required": false; }; "autoResize": { "alias": "autoResize"; "required": false; }; "align": { "alias": "align"; "required": false; }; }, {}, never, never, true, never>;
}

interface SicCommentMentionOption {
    id: string | number;
    label: string;
    /** Handle stored in the text instead of `id`, e.g. "ada_lovelace". Falls back to `String(id)` when omitted. */
    username?: string;
}
type SicCommentMentionSearch = (query: string) => SicCommentMentionOption[] | Promise<SicCommentMentionOption[]> | Observable<SicCommentMentionOption[]>;
interface SicCommentTextPart {
    text: string;
    type: 'plain' | 'mention' | 'hashtag';
}
/**
 * Splits raw comment text into plain/mention/hashtag runs for the highlight
 * overlay. A textarea can't color part of its own text, so the overlay is a
 * same-sized, identically-styled layer drawn behind an otherwise-transparent
 * textarea (see the component's template/CSS) — this is what produces its content.
 *
 * `mentionLabels` are full display names already inserted via the picker
 * (e.g. "Ada Lovelace") — they may contain spaces, so they need their own
 * alternation on top of the plain `@word` pattern used while a mention is
 * still being typed/searched.
 */
declare function splitCommentHighlightParts(text: string, mentionLabels?: string[]): SicCommentTextPart[];
/**
 * For displaying a *posted* comment elsewhere in your app: mentions are
 * stored as `@id`/`@username` (see `SicCommentMentionOption.username`), not
 * the person's display name — call this to swap each one back to a name
 * using your own user directory/lookup. `resolve` returning `undefined`
 * leaves that token as-is (e.g. an unknown/deleted user).
 */
declare function resolveMentionDisplay(text: string, resolve: (usernameOrId: string) => string | undefined): string;
declare class SicInputCommentComponent extends SicFormControlBase<string> {
    private readonly sicConfig;
    private readonly overlay;
    private readonly viewContainerRef;
    name?: string;
    placeholder: string;
    rows: number;
    maxlength?: number;
    autoResize: boolean;
    align: SicTextAlign;
    /** Turns the "@mention" picker on/off. */
    enableMentions: boolean;
    /** Called with the text typed after "@" — return (or resolve/emit) the options to show. */
    mentionSearch?: SicCommentMentionSearch;
    /** Turns "#hashtag" recognition on/off. A hashtag is recognized once terminated by a space. */
    enableHashtags: boolean;
    /** Turns the attach-file control on/off. */
    enableUpload: boolean;
    accept: string;
    multiple: boolean;
    maxSizeMb: number;
    files: File[];
    mentionClick: EventEmitter<SicCommentMentionOption>;
    hashtagClick: EventEmitter<string>;
    filesChange: EventEmitter<File[]>;
    rejected: EventEmitter<File[]>;
    private textareaRef?;
    private highlightRef?;
    private fileInputRef?;
    private wrapperRef;
    private mentionsTemplateRef?;
    readonly hostClass = true;
    get isAlignCenter(): boolean;
    get isAlignRight(): boolean;
    get noMatchesText(): string;
    get loadingText(): string;
    get attachFileLabel(): string;
    get removeFileLabel(): string;
    readonly fieldId: string;
    /** Stored/emitted form, e.g. "hello @1" — mentions encoded as id/username. */
    value: string;
    /** Edited form shown in the textarea, e.g. "hello @Ada Lovelace" — mentions expanded to their full label. */
    displayValue: string;
    dragOver: boolean;
    /** Text typed after the triggering "@", or `null` while the picker is closed. */
    mentionQuery: string | null;
    mentionOptions: SicCommentMentionOption[];
    mentionLoading: boolean;
    activeMentionIndex: number;
    private mentionTriggerIndex;
    private mentionRequestId;
    private mentionSub?;
    private mentionsOverlayRef?;
    private readonly previewUrls;
    /** label -> option, used to encode a display mention back to its stored id/username. */
    private readonly mentionsByLabel;
    /** id/username (as stored in `value`) -> label, used to decode a written-in value for display. */
    private readonly labelsByMentionId;
    ngOnDestroy(): void;
    writeValue(value: string | null | undefined): void;
    get highlightParts(): SicCommentTextPart[];
    /** Replaces each known "@Full Label" run in `display` with its stored "@id"/"@username" token. */
    private encodeForStorage;
    private registerMention;
    handleScroll(): void;
    handleInput(event: Event): void;
    handleKeydown(event: KeyboardEvent): void;
    handleBlur(): void;
    selectMention(option: SicCommentMentionOption): void;
    openFilePicker(): void;
    handleFileInput(event: Event): void;
    handleDrop(event: DragEvent): void;
    handleDragOver(event: DragEvent): void;
    handleDragLeave(): void;
    removeFile(file: File): void;
    previewUrlFor(file: File): string | null;
    private addFiles;
    private detectMentionTrigger;
    private openMentionsOverlay;
    private closeMentionsOverlay;
    private runMentionSearch;
    private detectCompletedHashtag;
    private closeMentionPicker;
    static ɵfac: i0.ɵɵFactoryDeclaration<SicInputCommentComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<SicInputCommentComponent, "sic-input-comment", never, { "name": { "alias": "name"; "required": false; }; "placeholder": { "alias": "placeholder"; "required": false; }; "rows": { "alias": "rows"; "required": false; }; "maxlength": { "alias": "maxlength"; "required": false; }; "autoResize": { "alias": "autoResize"; "required": false; }; "align": { "alias": "align"; "required": false; }; "enableMentions": { "alias": "enableMentions"; "required": false; }; "mentionSearch": { "alias": "mentionSearch"; "required": false; }; "enableHashtags": { "alias": "enableHashtags"; "required": false; }; "enableUpload": { "alias": "enableUpload"; "required": false; }; "accept": { "alias": "accept"; "required": false; }; "multiple": { "alias": "multiple"; "required": false; }; "maxSizeMb": { "alias": "maxSizeMb"; "required": false; }; "files": { "alias": "files"; "required": false; }; }, { "mentionClick": "mentionClick"; "hashtagClick": "hashtagClick"; "filesChange": "filesChange"; "rejected": "rejected"; }, never, never, true, never>;
}

/**
 * A file already uploaded/persisted for a posted comment — not `File`, since sic-input-comment's
 * `files: File[]` only exists client-side before submit. Once the host app has actually uploaded
 * them (e.g. from that same `files` array), it has URLs instead, which is what this displays.
 */
interface SicViewCommentAttachment {
    name: string;
    url: string;
    type?: string;
    sizeBytes?: number;
}
declare class SicViewCommentComponent {
    /** Raw comment text as produced by sic-input-comment's `value` — mentions encoded as "@id"/"@username". */
    text: string;
    /** Attachments already uploaded/persisted for this comment (see `SicViewCommentAttachment`). */
    attachments: SicViewCommentAttachment[];
    /** Resolves a mention's stored id/username to its display name, same shape as `resolveMentionDisplay`'s `resolve` param. Omit to show raw "@id" tokens as-is. */
    resolveMention?: (usernameOrId: string) => string | undefined;
    author: string;
    avatarUrl?: string;
    timestamp?: string | Date;
    mentionClick: EventEmitter<string>;
    hashtagClick: EventEmitter<string>;
    attachmentClick: EventEmitter<SicViewCommentAttachment>;
    readonly hostClass = true;
    /**
     * Splits the *raw* stored text (mentions still as "@id"/"@username") first, then resolves each
     * mention part's display label individually — resolving the whole string up front (as
     * `resolveMentionDisplay` does) would substitute in a label that can contain spaces, which the
     * highlighter's regex can no longer tell apart from surrounding plain text.
     */
    get parts(): SicCommentTextPart[];
    isImage(attachment: SicViewCommentAttachment): boolean;
    formatSize(sizeBytes: number | undefined): string;
    handlePartClick(part: SicCommentTextPart): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<SicViewCommentComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<SicViewCommentComponent, "sic-view-comment", never, { "text": { "alias": "text"; "required": false; }; "attachments": { "alias": "attachments"; "required": false; }; "resolveMention": { "alias": "resolveMention"; "required": false; }; "author": { "alias": "author"; "required": false; }; "avatarUrl": { "alias": "avatarUrl"; "required": false; }; "timestamp": { "alias": "timestamp"; "required": false; }; }, { "mentionClick": "mentionClick"; "hashtagClick": "hashtagClick"; "attachmentClick": "attachmentClick"; }, never, never, true, never>;
}

interface SicPhoneCountry {
    code: string;
    dialCode: string;
    name: string;
}
/** ISO 3166-1 alpha-2 → international calling code, sourced from countrycode.org. */
declare const SIC_DEFAULT_PHONE_COUNTRIES: SicPhoneCountry[];
declare class SicInputPhoneComponent extends SicFormControlBase<string> {
    name?: string;
    placeholder: string;
    countries: SicPhoneCountry[];
    align: SicTextAlign;
    readonly hostClass = true;
    get isAlignCenter(): boolean;
    get isAlignRight(): boolean;
    private phoneFieldRef?;
    private dialTriggerRef?;
    private optionsListRef?;
    private dialWrapRef;
    private panelTemplateRef?;
    private readonly platformId;
    private readonly elementRef;
    private readonly overlay;
    private readonly viewContainerRef;
    private panelOverlayRef?;
    /**
     * Explicit label→control association. Without it, clicking any non-control
     * descendant of the wrapping <label> (e.g. a dropdown option) makes the
     * browser forward a synthetic click to the FIRST labelable element inside
     * the label — which would be the dial-code trigger button, reopening the
     * panel right after selection closed it.
     */
    readonly fieldId: string;
    value: string;
    selectedCountryCode: string;
    open: boolean;
    activeIndex: number;
    get selectedCountry(): SicPhoneCountry | undefined;
    writeValue(value: string | null | undefined): void;
    ngOnDestroy(): void;
    handleDocumentClick(event: MouseEvent): void;
    handleTriggerClick(event: MouseEvent): void;
    openPanel(): void;
    closePanel(): void;
    private openPanelOverlay;
    private closePanelOverlay;
    selectCountry(event: MouseEvent | undefined, country: SicPhoneCountry): void;
    handleDialKeydown(event: KeyboardEvent): void;
    handleInput(event: Event): void;
    handleBlur(): void;
    private emit;
    private scrollActiveIntoView;
    private detectDefaultCountryCode;
    static ɵfac: i0.ɵɵFactoryDeclaration<SicInputPhoneComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<SicInputPhoneComponent, "sic-input-phone", never, { "name": { "alias": "name"; "required": false; }; "placeholder": { "alias": "placeholder"; "required": false; }; "countries": { "alias": "countries"; "required": false; }; "align": { "alias": "align"; "required": false; }; }, {}, never, never, true, never>;
}

type SicTagColor = 'primary' | 'success' | 'danger' | 'warning' | 'neutral';
interface SicTagItem {
    text: string;
    color?: SicTagColor;
    /** Overrides the component's `closable` input for this one tag. */
    closable?: boolean;
}
declare class SicTagComponent {
    color: SicTagColor;
    closable: boolean;
    /** Renders one pill per entry instead of the projected content — pass `[{ text, color }]`. */
    items?: SicTagItem[];
    closed: EventEmitter<void>;
    itemClosed: EventEmitter<{
        item: SicTagItem;
        index: number;
    }>;
    get hostClasses(): string;
    isItemClosable(item: SicTagItem): boolean;
    removeItem(item: SicTagItem, index: number, event: MouseEvent): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<SicTagComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<SicTagComponent, "sic-tag", never, { "color": { "alias": "color"; "required": false; }; "closable": { "alias": "closable"; "required": false; }; "items": { "alias": "items"; "required": false; }; }, { "closed": "closed"; "itemClosed": "itemClosed"; }, never, ["*"], true, never>;
}

declare class SicInputTagComponent extends SicFormControlBase<string> {
    /** Character (or string) that ends a tag while typing. Also used to join the committed tags into the exported string value. */
    delimiter: string;
    placeholder: string;
    /** Truncates any tag longer than this many characters (typed or pasted). */
    maxTagLength?: number;
    /** Once this many tags exist, no more can be added — the input is disabled. */
    maxTags?: number;
    /** Color of the rendered tag pills (see sic-tag's `color`). */
    tagColor: SicTagColor;
    private inputRef?;
    readonly hostClass = true;
    readonly fieldId: string;
    value: string;
    tags: string[];
    inputValue: string;
    get tagItems(): SicTagItem[];
    get isAtMaxTags(): boolean;
    writeValue(value: string | null | undefined): void;
    focusInput(): void;
    handleInput(event: Event): void;
    handleKeydown(event: KeyboardEvent): void;
    handleBlur(): void;
    removeTag(index: number): void;
    /** Adds `raw` as a new tag if it's non-empty and under the tag-count limit. Returns whether it was added. */
    private addTag;
    private emitTags;
    private clampLength;
    private splitTags;
    static ɵfac: i0.ɵɵFactoryDeclaration<SicInputTagComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<SicInputTagComponent, "sic-input-tag", never, { "delimiter": { "alias": "delimiter"; "required": false; }; "placeholder": { "alias": "placeholder"; "required": false; }; "maxTagLength": { "alias": "maxTagLength"; "required": false; }; "maxTags": { "alias": "maxTags"; "required": false; }; "tagColor": { "alias": "tagColor"; "required": false; }; }, {}, never, never, true, never>;
}

type SicComboboxValue = unknown | unknown[] | null;
interface SicComboboxQueryPayload {
    keyword?: string;
    value?: unknown;
    pageNo: number;
    pageSize: number;
}
/**
 * Emitted through `search` whenever isPaging = true needs data from the
 * caller: typing a keyword (pageNo:1), scrolling to load the next page
 * (pageNo++), or resolving the display label for a value written into the
 * formControl (value set, pageNo:1, pageSize:1). Call `options.update(items)`
 * with the fetched page — the component owns pagination/append/loading state
 * from there, no [options] input required while isPaging is true.
 */
interface SicComboboxQueryEvent<T = unknown> extends SicComboboxQueryPayload {
    options: {
        update: (items: T[]) => void;
    };
}
interface SicComboboxOptionContext<T> {
    $implicit: T;
    selected: boolean;
    active: boolean;
}
interface SicComboboxDisplayContext<T> {
    $implicit: T[];
    multi: boolean;
}
declare class SicComboboxComponent<T = unknown> extends SicFormControlBase<SicComboboxValue> implements OnDestroy {
    private readonly sicConfig;
    options: T[];
    optionLabel: keyof T | ((option: T) => string);
    optionValue: keyof T | ((option: T) => unknown);
    placeholder: string;
    multi: boolean;
    searchable: boolean;
    isPaging: boolean;
    pageSize: number;
    align: SicTextAlign;
    clearable: boolean;
    search: EventEmitter<SicComboboxQueryEvent<T>>;
    optionTemplate?: TemplateRef<SicComboboxOptionContext<T>>;
    displayTemplate?: TemplateRef<SicComboboxDisplayContext<T>>;
    private readonly inputRef?;
    private readonly panelRef?;
    readonly hostClass = true;
    get isAlignCenter(): boolean;
    get isAlignRight(): boolean;
    get noOptionsText(): string;
    value: SicComboboxValue;
    open: boolean;
    query: string;
    loadingMore: boolean;
    activeIndex: number;
    /**
     * The panel is positioned with `position: fixed` (viewport coordinates,
     * recomputed on open/scroll/resize) instead of `absolute` so it can escape
     * an ancestor with `overflow: auto`/`clip` — e.g. a horizontally-scrolling
     * sic-gridpanel cell — instead of being clipped by it.
     */
    panelTop: number;
    panelLeft: number;
    panelWidth: number;
    private loadedOptions;
    private selectedOptions;
    private pageNo;
    private hasMore;
    private resolving;
    private queryDebounce?;
    private readonly isBrowser;
    private readonly handleAncestorScroll;
    ngOnInit(): void;
    ngOnDestroy(): void;
    handleWindowResize(): void;
    private get dataset();
    get filteredOptions(): T[];
    get selectedLabel(): string;
    get fieldValue(): string;
    get showDisplayOverlay(): boolean;
    get showClear(): boolean;
    get selectedOptionsView(): T[];
    labelFor(option: T): string;
    valueFor(option: T): unknown;
    isSelected(option: T): boolean;
    writeValue(value: SicComboboxValue): void;
    handleFocus(): void;
    handleBlur(): void;
    handleQuery(event: Event): void;
    handleKeydown(event: KeyboardEvent): void;
    onOptionsScroll(event: Event): void;
    selectOption(option: T): void;
    clear(event: MouseEvent): void;
    private syncSelectedFromValue;
    private updatePanelPosition;
    private clampPanelToViewport;
    private emitQuery;
    private applyFetchedOptions;
    static ɵfac: i0.ɵɵFactoryDeclaration<SicComboboxComponent<any>, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<SicComboboxComponent<any>, "sic-combobox", never, { "options": { "alias": "options"; "required": false; }; "optionLabel": { "alias": "optionLabel"; "required": false; }; "optionValue": { "alias": "optionValue"; "required": false; }; "placeholder": { "alias": "placeholder"; "required": false; }; "multi": { "alias": "multi"; "required": false; }; "searchable": { "alias": "searchable"; "required": false; }; "isPaging": { "alias": "isPaging"; "required": false; }; "pageSize": { "alias": "pageSize"; "required": false; }; "align": { "alias": "align"; "required": false; }; "clearable": { "alias": "clearable"; "required": false; }; }, { "search": "search"; }, ["optionTemplate", "displayTemplate"], never, true, never>;
}

declare class SicCheckboxComponent extends SicFormControlBase<unknown> {
    checkedValue: unknown;
    uncheckedValue: unknown;
    readonly hostClass = true;
    value: unknown;
    get checked(): boolean;
    onCheckboxChange(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<SicCheckboxComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<SicCheckboxComponent, "sic-checkbox", never, { "checkedValue": { "alias": "checkedValue"; "required": false; }; "uncheckedValue": { "alias": "uncheckedValue"; "required": false; }; }, {}, never, never, true, never>;
}

declare class SicSwitchComponent extends SicFormControlBase<boolean> {
    checkedValue: unknown;
    uncheckedValue: unknown;
    readonly hostClass = true;
    value: boolean;
    get checked(): boolean;
    onToggle(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<SicSwitchComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<SicSwitchComponent, "sic-switch", never, { "checkedValue": { "alias": "checkedValue"; "required": false; }; "uncheckedValue": { "alias": "uncheckedValue"; "required": false; }; }, {}, never, never, true, never>;
}

type SicRangeValue = number | [number, number];
declare class SicRangeComponent extends SicFormControlBase<SicRangeValue> {
    min: number;
    max: number;
    step: number;
    dual: boolean;
    readonly hostClass = true;
    value: SicRangeValue;
    get low(): number;
    get high(): number;
    writeValue(value: SicRangeValue | null | undefined): void;
    handleLowChange(event: Event): void;
    handleHighChange(event: Event): void;
    handleBlur(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<SicRangeComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<SicRangeComponent, "sic-range", never, { "min": { "alias": "min"; "required": false; }; "max": { "alias": "max"; "required": false; }; "step": { "alias": "step"; "required": false; }; "dual": { "alias": "dual"; "required": false; }; }, {}, never, never, true, never>;
}

type SicDateEra = 'BE' | 'CE';
type SicDatepickerMode = 'day' | 'month' | 'year';
type SicDatepickerView = SicDatepickerMode;
interface SicDayCell {
    date: Dayjs;
    label: string;
    inMonth: boolean;
    isToday: boolean;
    isSelected: boolean;
    isCursor: boolean;
    disabled: boolean;
}
interface SicMonthCell {
    month: number;
    label: string;
    isSelected: boolean;
    isCursor: boolean;
    disabled: boolean;
}
interface SicYearCell {
    year: number;
    label: string;
    isSelected: boolean;
    isCursor: boolean;
    disabled: boolean;
}
declare class SicDatepickerComponent extends SicFormControlBase<Date | string | null> {
    private readonly sicConfig;
    min?: Date | string | null;
    max?: Date | string | null;
    outputType: 'date' | 'string';
    align: SicTextAlign;
    placeholder: string;
    /** Display format for the field. Tokens: yyyy, yy, MMMM, MMM, MM, M, dd, d, EEEE, EEE. */
    format: string;
    /** Year numbering shown to the user. Storage/output is always the real (CE) date. */
    era: SicDateEra;
    /** dayjs locale code for month/weekday names. Import the matching `dayjs/locale/<code>`
     *  package yourself before use — dayjs falls back to English for unregistered locales. */
    locale: string;
    /** Granularity the picker commits to. 'month' skips the day grid, 'year' skips both. */
    mode: SicDatepickerMode;
    weekStartsOn: 0 | 1;
    clearable: boolean;
    readonly hostClass = true;
    get isAlignCenter(): boolean;
    get isAlignRight(): boolean;
    private triggerRef?;
    private fieldWrapRef?;
    private panelRef?;
    private readonly elementRef;
    /** Set right before we refocus the trigger ourselves (after commit/Escape), so
     *  the (focus) handler doesn't treat that as a user focus and reopen. */
    private suppressAutoOpen;
    private readonly isBrowser;
    private readonly handleAncestorScroll;
    readonly fieldId: string;
    value: Date | string | null;
    open: boolean;
    view: SicDatepickerView;
    focusedDate: dayjs.Dayjs;
    /**
     * The panel is positioned with `position: fixed` (viewport coordinates,
     * recomputed on open/scroll/resize) instead of `absolute` so it can escape
     * an ancestor with `overflow: auto`/`clip` — e.g. a sic-gridpanel cell —
     * instead of being clipped by it.
     */
    panelTop: number;
    panelLeft: number;
    /** Only true once the user starts arrow-keying — keeps the cursor ring from
     *  appearing when just clicking the prev/next nav buttons with a mouse
     *  (dayjs().add(n,'month') keeps the day-of-month, which used to make every
     *  month's Nth day look highlighted while merely browsing). */
    keyboardActive: boolean;
    ngOnInit(): void;
    ngOnDestroy(): void;
    handleWindowResize(): void;
    writeValue(value: Date | string | null | undefined): void;
    get displayValue(): string;
    get showClear(): boolean;
    clearValue(event: MouseEvent): void;
    get headerLabel(): string;
    get weekdayLabels(): string[];
    get dayCells(): SicDayCell[];
    get monthCells(): SicMonthCell[];
    get yearCells(): SicYearCell[];
    private get yearWindowStart();
    private get selectedDate();
    private get minDate();
    private get maxDate();
    private isDayDisabled;
    private isMonthDisabled;
    private isYearDisabled;
    handleDocumentClick(event: MouseEvent): void;
    handleTriggerClick(event: MouseEvent): void;
    handleTriggerFocus(): void;
    handleFocusOut(event: FocusEvent): void;
    openPanel(): void;
    closePanel(): void;
    private refocusTrigger;
    private updatePanelPosition;
    private clampPanelToViewport;
    drillUp(): void;
    stepPrimary(direction: 1 | -1): void;
    selectDay(cell: SicDayCell, event?: MouseEvent): void;
    selectMonth(cell: SicMonthCell, event?: MouseEvent): void;
    selectYear(cell: SicYearCell, event?: MouseEvent): void;
    handleTriggerKeydown(event: KeyboardEvent): void;
    private arrowStep;
    private activateFocused;
    private commit;
    static ɵfac: i0.ɵɵFactoryDeclaration<SicDatepickerComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<SicDatepickerComponent, "sic-datepicker", never, { "min": { "alias": "min"; "required": false; }; "max": { "alias": "max"; "required": false; }; "outputType": { "alias": "outputType"; "required": false; }; "align": { "alias": "align"; "required": false; }; "placeholder": { "alias": "placeholder"; "required": false; }; "format": { "alias": "format"; "required": false; }; "era": { "alias": "era"; "required": false; }; "locale": { "alias": "locale"; "required": false; }; "mode": { "alias": "mode"; "required": false; }; "weekStartsOn": { "alias": "weekStartsOn"; "required": false; }; "clearable": { "alias": "clearable"; "required": false; }; }, {}, never, never, true, never>;
}

type SicTimeSegment = 'hour' | 'minute';
interface SicClockNumber {
    value: number;
    label: string;
    transform: string;
}
declare class SicTimepickerComponent extends SicFormControlBase<Date | null> {
    /** Real datetime bounds (Date or a value dayjs can parse) — only the time-of-day is enforced, evaluated against the date currently held (or today, if empty). */
    min?: Date | string | null;
    max?: Date | string | null;
    align: SicTextAlign;
    placeholder: string;
    clearable: boolean;
    private triggerRef?;
    private fieldWrapRef?;
    private panelRef?;
    private faceRef?;
    private readonly platformId;
    private readonly elementRef;
    /**
     * Timestamp of the last time we closed the panel and refocused the trigger.
     * `handleTriggerFocus` ignores any focus event within `REOPEN_GUARD_MS` of
     * this, no matter what caused it — a plain single-consume flag isn't
     * enough here, because on touch devices the browser can shift focus onto a
     * panel-internal button (if the release happens to land on one) at a delay
     * that varies by browser/OS, and once that focus eventually settles back
     * onto the trigger it would otherwise look like a fresh, deliberate focus
     * and reopen the panel right after it closed.
     */
    private justClosedAt;
    private readonly isBrowser;
    /** True while the user is pressing/dragging on the clock face — the hand follows the pointer live; the value only commits on release. */
    dragging: boolean;
    /** True once the current drag/tap's most recent position landed on a disabled hour/minute — release must then be a no-op (stay open, same segment) instead of advancing/committing as if a value had actually changed. */
    private pointerOnDisabledTarget;
    private readonly handleAncestorScroll;
    readonly fieldId: string;
    readonly hostClass = true;
    get isAlignCenter(): boolean;
    get isAlignRight(): boolean;
    value: Date | null;
    open: boolean;
    segment: SicTimeSegment;
    hour: number;
    minute: number;
    /** Date (year/month/day) the currently open panel's hour/minute get committed onto — the existing value's date, or today if there wasn't one. Fixed for the lifetime of one open/commit cycle so dragging never shifts the date underfoot. */
    private contextDate;
    /**
     * The panel is positioned with `position: fixed` (viewport coordinates,
     * recomputed on open/scroll/resize) instead of `absolute` so it can escape
     * an ancestor with `overflow: auto`/`clip` — e.g. a sic-gridpanel cell —
     * instead of being clipped by it.
     */
    panelTop: number;
    panelLeft: number;
    ngOnInit(): void;
    ngOnDestroy(): void;
    handleWindowResize(): void;
    writeValue(value: Date | string | null | undefined): void;
    get displayValue(): string;
    get showClear(): boolean;
    clearValue(event: MouseEvent): void;
    private toValidDate;
    get hourOuterNumbers(): SicClockNumber[];
    get hourInnerNumbers(): SicClockNumber[];
    get minuteNumbers(): SicClockNumber[];
    get handAngle(): number;
    get handLength(): number;
    private buildRing;
    private get minDate();
    private get maxDate();
    /** An hour is only disabled if every minute within it falls outside [min, max] on the current context date. */
    isHourDisabled(h: number): boolean;
    isMinuteDisabled(m: number): boolean;
    handleFocusOut(event: FocusEvent): void;
    handleTriggerFocus(): void;
    handleTriggerClick(event: MouseEvent): void;
    private isWithinReopenGuard;
    handleKeydown(event: KeyboardEvent): void;
    setSegment(segment: SicTimeSegment, event?: MouseEvent): void;
    /**
     * Selecting a number on the clock face — a discrete tap and a
     * press-and-hold-then-slide are the same gesture here (a tap is just a
     * zero-movement drag), handled entirely through pointer events rather than
     * a `(click)` on each number button: pointerdown starts a drag (even when
     * it lands directly on a number, so holding one and sliding away still
     * works) and updates the value live via `updateFromPointer`, and release
     * finalizes it (advance to the minute segment, or commit and close). Using
     * pointer events exclusively — instead of also wiring `(click)` on the
     * number buttons and suppressing the browser's redundant compatibility
     * click — avoids relying on exactly-once click-suppression timing, which
     * differs enough across mobile browsers to be unreliable.
     */
    handleFacePointerDown(event: PointerEvent): void;
    handleDocumentPointerMove(event: PointerEvent): void;
    handleDocumentPointerUp(): void;
    private updateFromPointer;
    openPanel(): void;
    closePanel(): void;
    private updatePanelPosition;
    private clampPanelToViewport;
    private adjust;
    private commit;
    private refocusTrigger;
    static ɵfac: i0.ɵɵFactoryDeclaration<SicTimepickerComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<SicTimepickerComponent, "sic-timepicker", never, { "min": { "alias": "min"; "required": false; }; "max": { "alias": "max"; "required": false; }; "align": { "alias": "align"; "required": false; }; "placeholder": { "alias": "placeholder"; "required": false; }; "clearable": { "alias": "clearable"; "required": false; }; }, {}, never, never, true, never>;
}

declare class SicColorpickerComponent extends SicFormControlBase<string | null> {
    allowText: boolean;
    align: SicTextAlign;
    clearable: boolean;
    readonly hostClass = true;
    get isAlignCenter(): boolean;
    get isAlignRight(): boolean;
    value: string | null;
    /** Native <input type="color"> can't represent "no color" — this is only
     *  what the swatch itself renders; `value` (the real, emitted state) stays null. */
    get swatchValue(): string;
    get showClear(): boolean;
    writeValue(value: string | null | undefined): void;
    handleColorInput(event: Event): void;
    handleTextInput(event: Event): void;
    handleTextBlur(event: Event): void;
    private isValidHex;
    clear(event: MouseEvent): void;
    handleBlur(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<SicColorpickerComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<SicColorpickerComponent, "sic-colorpicker", never, { "allowText": { "alias": "allowText"; "required": false; }; "align": { "alias": "align"; "required": false; }; "clearable": { "alias": "clearable"; "required": false; }; }, {}, never, never, true, never>;
}

interface SicUploadProgress {
    file: File;
    percent: number;
}
declare class SicUploadComponent extends SicFormControlBase<File[]> {
    private readonly sicConfig;
    accept: string;
    multiple: boolean;
    maxSizeMb: number;
    progress: EventEmitter<SicUploadProgress>;
    rejected: EventEmitter<File[]>;
    fileInput?: ElementRef<HTMLInputElement>;
    readonly hostClass = true;
    get dragDropHintText(): string;
    value: File[];
    dragOver: boolean;
    writeValue(value: File[] | null | undefined): void;
    openPicker(): void;
    handleFileInput(event: Event): void;
    handleDrop(event: DragEvent): void;
    handleDragOver(event: DragEvent): void;
    handleDragLeave(): void;
    removeFile(file: File): void;
    private addFiles;
    static ɵfac: i0.ɵɵFactoryDeclaration<SicUploadComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<SicUploadComponent, "sic-upload", never, { "accept": { "alias": "accept"; "required": false; }; "multiple": { "alias": "multiple"; "required": false; }; "maxSizeMb": { "alias": "maxSizeMb"; "required": false; }; }, { "progress": "progress"; "rejected": "rejected"; }, never, never, true, never>;
}

declare class SicRatingComponent extends SicFormControlBase<number> {
    max: number;
    allowHalf: boolean;
    readonly hostClass = true;
    value: number;
    hovered: number | null;
    get stars(): number[];
    displayValue(star: number): 'full' | 'half' | 'empty';
    setValue(star: number, event: MouseEvent): void;
    setHover(star: number | null): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<SicRatingComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<SicRatingComponent, "sic-rating", never, { "max": { "alias": "max"; "required": false; }; "allowHalf": { "alias": "allowHalf"; "required": false; }; }, {}, never, never, true, never>;
}

/** Accepts sic-flex's own shorthand keywords ('start'/'end'/'between'/...) as well as the raw CSS
 * values they map to ('flex-start'/'space-between'/...), since passing the literal CSS keyword by
 * habit is an easy mistake — silently falling through to `undefined` would strip the style
 * entirely instead of doing what was actually asked. */
type SicFlexAlign = 'start' | 'center' | 'end' | 'stretch' | 'baseline' | 'flex-start' | 'flex-end';
type SicFlexJustify = 'start' | 'center' | 'end' | 'between' | 'around' | 'evenly' | 'flex-start' | 'flex-end' | 'space-between' | 'space-around' | 'space-evenly';
declare class SicFlexComponent {
    direction: 'row' | 'column' | 'row-reverse' | 'column-reverse';
    align: SicFlexAlign;
    justify: SicFlexJustify;
    wrap: 'nowrap' | 'wrap' | 'wrap-reverse';
    gap: string;
    readonly display = "flex";
    get flexDirection(): "row" | "column" | "row-reverse" | "column-reverse";
    get alignItems(): string;
    get justifyContent(): string;
    get flexWrap(): "nowrap" | "wrap" | "wrap-reverse";
    get flexGap(): string;
    static ɵfac: i0.ɵɵFactoryDeclaration<SicFlexComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<SicFlexComponent, "sic-flex", never, { "direction": { "alias": "direction"; "required": false; }; "align": { "alias": "align"; "required": false; }; "justify": { "alias": "justify"; "required": false; }; "wrap": { "alias": "wrap"; "required": false; }; "gap": { "alias": "gap"; "required": false; }; }, {}, never, ["*"], true, never>;
}

declare class SicGridComponent {
    cols: number;
    gap: string;
    /** Breakpoint → column count, e.g. { sm: 1, md: 2, lg: 4 } */
    colsBreakpoints: Record<'sm' | 'md' | 'lg', number> | null;
    readonly display = "grid";
    get gridGap(): string;
    get responsive(): boolean;
    get gridCols(): string | null;
    get colsSm(): number;
    get colsMd(): number;
    get colsLg(): number;
    static ɵfac: i0.ɵɵFactoryDeclaration<SicGridComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<SicGridComponent, "sic-grid", never, { "cols": { "alias": "cols"; "required": false; }; "gap": { "alias": "gap"; "required": false; }; "colsBreakpoints": { "alias": "colsBreakpoints"; "required": false; }; }, {}, never, ["*"], true, never>;
}

declare class SicCardComponent {
    title?: string;
    bordered: boolean;
    elevated: boolean;
    readonly hostClass = true;
    get isBordered(): boolean;
    get isElevated(): boolean;
    static ɵfac: i0.ɵɵFactoryDeclaration<SicCardComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<SicCardComponent, "sic-card", never, { "title": { "alias": "title"; "required": false; }; "bordered": { "alias": "bordered"; "required": false; }; "elevated": { "alias": "elevated"; "required": false; }; }, {}, never, ["[sicCardHeader]", "*", "[sicCardFooter]"], true, never>;
}

type SicButtonVariant = 'solid' | 'outline' | 'ghost';
type SicButtonSize = 'sm' | 'md' | 'lg';
declare class SicButtonComponent {
    variant: SicButtonVariant;
    color: 'primary' | 'success' | 'danger' | 'warning';
    /** Default matches SicFormControlBase's default ('sm'), so a button sitting next to a default-sized sic-input/sic-combobox/etc. lines up without either side having to set `size` explicitly. */
    size: SicButtonSize;
    type: 'button' | 'submit' | 'reset';
    disabled: boolean;
    loading: boolean;
    block: boolean;
    /** Shrinks the whole rendered button on narrow phones (<=480px) — for a large CTA that would
     * otherwise crowd a small viewport, without needing a separate `size="sm"` binding just for it. */
    compactOnMobile: boolean;
    readonly hostClass = true;
    get isBlock(): boolean;
    get isCompactOnMobile(): boolean;
    static ɵfac: i0.ɵɵFactoryDeclaration<SicButtonComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<SicButtonComponent, "sic-button", never, { "variant": { "alias": "variant"; "required": false; }; "color": { "alias": "color"; "required": false; }; "size": { "alias": "size"; "required": false; }; "type": { "alias": "type"; "required": false; }; "disabled": { "alias": "disabled"; "required": false; }; "loading": { "alias": "loading"; "required": false; }; "block": { "alias": "block"; "required": false; }; "compactOnMobile": { "alias": "compactOnMobile"; "required": false; }; }, {}, never, ["[sicIconLeft]", "*", "[sicIconRight]"], true, never>;
}

/**
 * A real `<a>` styled exactly like `sic-button` (same variant/color/size, same CSS) — for cases
 * that need actual link semantics instead of a button with a click handler: right-click "open in
 * new tab", ctrl/cmd-click, crawlable `href`, `download`, etc.
 */
declare class SicALinkComponent {
    href?: string;
    target?: '_blank' | '_self' | '_parent' | '_top';
    /** Overrides the `target="_blank"` auto `rel="noopener noreferrer"` default. */
    rel?: string;
    /** `true` for a bare `download` attribute, or a string to suggest a filename. */
    download?: string | boolean;
    variant: SicButtonVariant;
    color: 'primary' | 'success' | 'danger' | 'warning';
    size: SicButtonSize;
    disabled: boolean;
    block: boolean;
    /** Shrinks the whole rendered link on narrow phones (<=480px), matching `sic-button`'s own input. */
    compactOnMobile: boolean;
    readonly hostClass = true;
    get isBlock(): boolean;
    get isCompactOnMobile(): boolean;
    get resolvedHref(): string | null;
    get resolvedRel(): string | null;
    get resolvedDownload(): string | null;
    handleClick(event: MouseEvent): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<SicALinkComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<SicALinkComponent, "sic-a-link", never, { "href": { "alias": "href"; "required": false; }; "target": { "alias": "target"; "required": false; }; "rel": { "alias": "rel"; "required": false; }; "download": { "alias": "download"; "required": false; }; "variant": { "alias": "variant"; "required": false; }; "color": { "alias": "color"; "required": false; }; "size": { "alias": "size"; "required": false; }; "disabled": { "alias": "disabled"; "required": false; }; "block": { "alias": "block"; "required": false; }; "compactOnMobile": { "alias": "compactOnMobile"; "required": false; }; }, {}, never, ["[sicIconLeft]", "*", "[sicIconRight]"], true, never>;
}

declare class SicButtonGroupComponent {
    attached: boolean;
    direction: 'row' | 'column';
    readonly hostClass = true;
    get isAttached(): boolean;
    get isColumn(): boolean;
    static ɵfac: i0.ɵɵFactoryDeclaration<SicButtonGroupComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<SicButtonGroupComponent, "sic-button-group", never, { "attached": { "alias": "attached"; "required": false; }; "direction": { "alias": "direction"; "required": false; }; }, {}, never, ["sic-button"], true, never>;
}

/**
 * A page-section wrapper: centered max-width column with responsive padding and scroll-margin
 * (for anchor-link navigation) by default. `[fullBleed]` drops that container for full-width
 * content (e.g. a hero image slider); `[bordered]` adds a top border (e.g. a page footer);
 * `[center]` centers any plain-text content projected into it. `[title]`/`[lead]` render an
 * optional centered heading/lead paragraph above the projected content.
 */
declare class SicSectionComponent {
    title?: string;
    lead?: string;
    fullBleed: boolean;
    bordered: boolean;
    center: boolean;
    readonly hostClass = true;
    get isFullBleed(): boolean;
    get isBordered(): boolean;
    get isCentered(): boolean;
    static ɵfac: i0.ɵɵFactoryDeclaration<SicSectionComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<SicSectionComponent, "sic-section", never, { "title": { "alias": "title"; "required": false; }; "lead": { "alias": "lead"; "required": false; }; "fullBleed": { "alias": "fullBleed"; "required": false; }; "bordered": { "alias": "bordered"; "required": false; }; "center": { "alias": "center"; "required": false; }; }, {}, never, ["*"], true, never>;
}

type SicShowBreakpoint = 'md' | 'lg';
/**
 * Shows or hides projected content at a breakpoint entirely through this component's own scoped
 * CSS — a real, typed component instead of a utility class the consumer has to memorize. Matches
 * the breakpoint scale sic-grid/sic-masonry already use (`md`: 768px, `lg`: 1024px). Renders as
 * `display: contents` when visible, so the wrapped content still participates directly in the
 * parent's own flex/grid layout instead of being boxed inside an extra element.
 */
declare class SicShowComponent {
    /** Visible from this breakpoint up, hidden below it. */
    from?: SicShowBreakpoint;
    /** Visible up to (below) this breakpoint, hidden from it up. */
    upTo?: SicShowBreakpoint;
    get isFromMd(): boolean;
    get isFromLg(): boolean;
    get isUpToMd(): boolean;
    get isUpToLg(): boolean;
    static ɵfac: i0.ɵɵFactoryDeclaration<SicShowComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<SicShowComponent, "sic-show", never, { "from": { "alias": "from"; "required": false; }; "upTo": { "alias": "upTo"; "required": false; }; }, {}, never, ["*"], true, never>;
}

type SicTextSize = 'sm' | 'md' | 'lg';
type SicTextWeight = 'normal' | 'semibold' | 'bold';
type SicTextColor = 'default' | 'muted' | 'active' | 'success';
/**
 * sic-ng's small typography primitive — size/weight/color read from tokens, so labels, captions,
 * and body copy scattered across a page (contact labels, card descriptions, footer captions, a
 * success message, ...) share one component instead of one-off custom CSS per spot.
 */
declare class SicTextComponent {
    size: SicTextSize;
    weight: SicTextWeight;
    color: SicTextColor;
    /** Renders as `display: block` instead of the default `inline`. */
    block: boolean;
    /** Uppercase + letter-spaced caption style, e.g. a footer section label. */
    eyebrow: boolean;
    readonly hostClass = true;
    get isSm(): boolean;
    get isLg(): boolean;
    get isSemibold(): boolean;
    get isBold(): boolean;
    get isMuted(): boolean;
    get isActive(): boolean;
    get isSuccess(): boolean;
    get isBlock(): boolean;
    get isEyebrow(): boolean;
    static ɵfac: i0.ɵɵFactoryDeclaration<SicTextComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<SicTextComponent, "sic-text", never, { "size": { "alias": "size"; "required": false; }; "weight": { "alias": "weight"; "required": false; }; "color": { "alias": "color"; "required": false; }; "block": { "alias": "block"; "required": false; }; "eyebrow": { "alias": "eyebrow"; "required": false; }; }, {}, never, ["*"], true, never>;
}

/** A round, tinted-primary badge for a leading icon/emoji — e.g. a contact-info row's icon. */
declare class SicIconBadgeComponent {
    static ɵfac: i0.ɵɵFactoryDeclaration<SicIconBadgeComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<SicIconBadgeComponent, "sic-icon-badge", never, {}, {}, never, ["*"], true, never>;
}

interface SicNavbarMenuItem {
    label: string;
    icon?: string;
    action?: string;
}
interface SicNavbarUser {
    name: string;
    email: string;
    avatarUrl?: string;
}
interface SicNavbarNotification {
    id: string | number;
    /** e.g. "requests permission to change" */
    message: string;
    /** Bold lead-in name shown before `message`, e.g. "Terry Franci". */
    actor?: string;
    /** Bold phrase shown after `message`, e.g. "Project - Nganter App". */
    target?: string;
    /** e.g. "Project" — shown before `time` in the meta line. */
    category?: string;
    /** e.g. "5 min ago" */
    time?: string;
    avatarUrl?: string;
    /** Falls back to a plain icon/initial when there's no avatarUrl. */
    icon?: string;
    status?: 'online' | 'offline' | 'busy' | 'away';
    read?: boolean;
}

/** Template context handed to every `sic-navbar` slot override: `let-navbar` for the component instance. */
interface SicNavbarTemplateContext {
    $implicit: unknown;
}
/** Wrap custom markup with `<ng-template sicNavbarHeader let-navbar>` to replace the brand/header slot. */
declare class SicNavbarHeaderDirective {
    static ɵfac: i0.ɵɵFactoryDeclaration<SicNavbarHeaderDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<SicNavbarHeaderDirective, "[sicNavbarHeader]", never, {}, {}, never, never, true, never>;
}
/** Wrap custom markup with `<ng-template sicNavbarLeft let-navbar>` to replace the sidebar-toggle row. */
declare class SicNavbarLeftDirective {
    static ɵfac: i0.ɵɵFactoryDeclaration<SicNavbarLeftDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<SicNavbarLeftDirective, "[sicNavbarLeft]", never, {}, {}, never, never, true, never>;
}
/** Wrap custom markup with `<ng-template sicNavbarRight let-navbar>` to replace the theme/notifications/user row. */
declare class SicNavbarRightDirective {
    static ɵfac: i0.ɵɵFactoryDeclaration<SicNavbarRightDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<SicNavbarRightDirective, "[sicNavbarRight]", never, {}, {}, never, never, true, never>;
}

declare class SicNavbarComponent {
    private readonly elementRef;
    private readonly sicConfig;
    sticky: boolean;
    /** Pins the navbar to the top of the viewport with `position: fixed` (floats above scrolled content, unlike `sticky` which stays within its normal document-flow slot). Takes precedence over `sticky` if both are set — remember to add top padding/margin to whatever follows so it isn't hidden underneath. */
    fixed: boolean;
    brand?: string;
    logo?: string;
    /** Mirrors sic-sidebar's `collapsed`/`collapsedChange` so both can bind to the same variable. */
    collapsed: boolean;
    /** No built-in UI reads this directly (left/right have no default template) — it's state your own sicNavbarLeft template can consult before rendering its own hamburger button. */
    showSidebarToggle: boolean;
    showThemeToggle: boolean;
    darkMode: boolean;
    showNotifications: boolean;
    notifications: SicNavbarNotification[];
    user?: SicNavbarUser;
    menuItems: SicNavbarMenuItem[];
    collapsedChange: EventEmitter<boolean>;
    darkModeChange: EventEmitter<boolean>;
    notificationClick: EventEmitter<SicNavbarNotification>;
    viewAllNotifications: EventEmitter<void>;
    menuItemClick: EventEmitter<SicNavbarMenuItem>;
    /** Custom `<ng-template sicNavbarHeader let-navbar>` replaces the default brand row. */
    headerTemplate?: TemplateRef<SicNavbarTemplateContext>;
    /** Custom `<ng-template sicNavbarLeft let-navbar>` replaces the sidebar-toggle row. */
    leftTemplate?: TemplateRef<SicNavbarTemplateContext>;
    /** Custom `<ng-template sicNavbarRight let-navbar>` replaces the theme/notifications/user row. */
    rightTemplate?: TemplateRef<SicNavbarTemplateContext>;
    get templateContext(): SicNavbarTemplateContext;
    readonly hostClass = true;
    get isSticky(): boolean;
    get isFixed(): boolean;
    notificationsOpen: boolean;
    userMenuOpen: boolean;
    get noNotificationsText(): string;
    get viewAllNotificationsText(): string;
    get hasUnread(): boolean;
    toggleSidebar(): void;
    toggleDarkMode(): void;
    toggleNotifications(event: Event): void;
    toggleUserMenu(event: Event): void;
    selectNotification(notification: SicNavbarNotification): void;
    closeNotifications(): void;
    handleViewAllNotifications(): void;
    selectMenuItem(item: SicNavbarMenuItem): void;
    handleDocumentClick(event: MouseEvent): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<SicNavbarComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<SicNavbarComponent, "sic-navbar", never, { "sticky": { "alias": "sticky"; "required": false; }; "fixed": { "alias": "fixed"; "required": false; }; "brand": { "alias": "brand"; "required": false; }; "logo": { "alias": "logo"; "required": false; }; "collapsed": { "alias": "collapsed"; "required": false; }; "showSidebarToggle": { "alias": "showSidebarToggle"; "required": false; }; "showThemeToggle": { "alias": "showThemeToggle"; "required": false; }; "darkMode": { "alias": "darkMode"; "required": false; }; "showNotifications": { "alias": "showNotifications"; "required": false; }; "notifications": { "alias": "notifications"; "required": false; }; "user": { "alias": "user"; "required": false; }; "menuItems": { "alias": "menuItems"; "required": false; }; }, { "collapsedChange": "collapsedChange"; "darkModeChange": "darkModeChange"; "notificationClick": "notificationClick"; "viewAllNotifications": "viewAllNotifications"; "menuItemClick": "menuItemClick"; }, ["headerTemplate", "leftTemplate", "rightTemplate"], never, true, never>;
}

interface SicSidebarItem {
    label: string;
    icon?: string;
    link?: string;
    /** Dot color for 'list' variant sections (e.g. a project/workspace color). */
    color?: string;
    /** Badge shown next to the label for 'menu' variant sections (e.g. an unread count). */
    badge?: string | number;
    badgeColor?: string;
    /** Nested submenu — items can nest their own `children` recursively with no depth limit. */
    children?: SicSidebarItem[];
}
interface SicSidebarSection {
    title?: string;
    items: SicSidebarItem[];
    /** 'menu' (default): icon + label + badge. 'list': color dot + label + chevron. */
    variant?: 'menu' | 'list';
}
interface SicSidebarUser {
    name: string;
    email: string;
    avatarUrl?: string;
}

/** Template context handed to every `sic-sidebar` slot override: `let-collapsed="collapsed"` etc. */
interface SicSidebarTemplateContext {
    $implicit: unknown;
    collapsed: boolean;
    expanded: boolean;
}
/** Wrap custom header markup with `<ng-template sicSidebarHeader>` to replace the logo/brand row. */
declare class SicSidebarHeaderDirective {
    static ɵfac: i0.ɵɵFactoryDeclaration<SicSidebarHeaderDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<SicSidebarHeaderDirective, "[sicSidebarHeader]", never, {}, {}, never, never, true, never>;
}
/** Wrap custom markup with `<ng-template sicSidebarSubheader>` to replace the search row. */
declare class SicSidebarSubheaderDirective {
    static ɵfac: i0.ɵɵFactoryDeclaration<SicSidebarSubheaderDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<SicSidebarSubheaderDirective, "[sicSidebarSubheader]", never, {}, {}, never, never, true, never>;
}
/** Wrap custom markup with `<ng-template sicSidebarMenu>` to replace the whole nav/sections list. */
declare class SicSidebarMenuDirective {
    static ɵfac: i0.ɵɵFactoryDeclaration<SicSidebarMenuDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<SicSidebarMenuDirective, "[sicSidebarMenu]", never, {}, {}, never, never, true, never>;
}
/** Wrap custom markup with `<ng-template sicSidebarFooter>` to replace the theme-toggle/user card row. */
declare class SicSidebarFooterDirective {
    static ɵfac: i0.ɵɵFactoryDeclaration<SicSidebarFooterDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<SicSidebarFooterDirective, "[sicSidebarFooter]", never, {}, {}, never, never, true, never>;
}

declare class SicSidebarComponent implements OnChanges, OnDestroy {
    private readonly cdr;
    /** Back-compat flat item list, rendered as a single untitled 'menu' section when `sections` isn't given. */
    items: SicSidebarItem[];
    sections: SicSidebarSection[];
    collapsed: boolean;
    activeLink?: string;
    /** Hides the built-in collapse/expand button — set this when some other control (e.g. a navbar hamburger) drives `collapsed` instead. */
    showToggle: boolean;
    /** 'rail' (default): collapsed sidebar shrinks to an icon-only rail. 'hidden': collapsed sidebar disappears entirely (0 width), same as the built-in mobile behavior, at any viewport size. */
    collapseMode: 'rail' | 'hidden';
    logo?: string;
    brand?: string;
    search: string;
    searchPlaceholder: string;
    darkMode: boolean;
    user?: SicSidebarUser;
    /** Overrides the accent color used for the active-item highlight and badges. */
    accentColor?: string;
    itemSelect: EventEmitter<SicSidebarItem>;
    collapsedChange: EventEmitter<boolean>;
    searchChange: EventEmitter<string>;
    darkModeChange: EventEmitter<boolean>;
    userAction: EventEmitter<SicSidebarUser>;
    /** Custom `<ng-template sicSidebarHeader let-collapsed="collapsed">` replaces the default logo/brand row. */
    headerTemplate?: TemplateRef<SicSidebarTemplateContext>;
    /** `<ng-template sicSidebarSubheader>` — the row below the header has no built-in UI, so this is the only way to render one (e.g. a search box using `search`/`searchChange`/`searchPlaceholder` below). */
    subheaderTemplate?: TemplateRef<SicSidebarTemplateContext>;
    /** Custom `<ng-template sicSidebarMenu>` replaces the default sections/nav entirely. */
    menuTemplate?: TemplateRef<SicSidebarTemplateContext>;
    /** `<ng-template sicSidebarFooter let-sidebar>` — the footer has no built-in UI, so this is the only way to render one (e.g. a theme toggle using `darkMode`/`darkModeChange`, or a user card using `user`/`userAction`, both below). */
    footerTemplate?: TemplateRef<SicSidebarTemplateContext>;
    get templateContext(): SicSidebarTemplateContext;
    readonly hostClass = true;
    get isCollapsed(): boolean;
    /** True while a collapsed sidebar is temporarily flared open to full width because the pointer is hovering over it. */
    get isPeeking(): boolean;
    get isHideCollapseMode(): boolean;
    get accentVar(): string | null;
    /** Whether the sidebar should currently render its full (labels + submenus) layout, either because it isn't collapsed or because it's peeking open. */
    get expanded(): boolean;
    expandedLabels: Set<string>;
    private hovering;
    /**
     * A brief close-delay absorbs the spurious mouseleave→mouseenter pair that some browsers fire
     * when the peek panel's geometry (position/box-shadow) changes right under a stationary cursor —
     * without it, that single-frame hit-test glitch reads as the sidebar endlessly flickering open/closed.
     */
    private closeTimer?;
    onMouseEnter(): void;
    onMouseLeave(): void;
    ngOnDestroy(): void;
    private clearCloseTimer;
    get resolvedSections(): SicSidebarSection[];
    ngOnChanges(changes: SimpleChanges): void;
    /** Auto-expands every collapsed submenu that contains the item matching `activeLink`, so navigating straight to a deep URL still reveals it. */
    private expandAncestorsOfActiveLink;
    private expandAncestorsInList;
    toggleCollapsed(): void;
    toggleExpand(item: SicSidebarItem): void;
    isExpanded(item: SicSidebarItem): boolean;
    selectItem(item: SicSidebarItem): void;
    handleSearchInput(value: string): void;
    setDarkMode(value: boolean): void;
    handleUserAction(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<SicSidebarComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<SicSidebarComponent, "sic-sidebar", never, { "items": { "alias": "items"; "required": false; }; "sections": { "alias": "sections"; "required": false; }; "collapsed": { "alias": "collapsed"; "required": false; }; "activeLink": { "alias": "activeLink"; "required": false; }; "showToggle": { "alias": "showToggle"; "required": false; }; "collapseMode": { "alias": "collapseMode"; "required": false; }; "logo": { "alias": "logo"; "required": false; }; "brand": { "alias": "brand"; "required": false; }; "search": { "alias": "search"; "required": false; }; "searchPlaceholder": { "alias": "searchPlaceholder"; "required": false; }; "darkMode": { "alias": "darkMode"; "required": false; }; "user": { "alias": "user"; "required": false; }; "accentColor": { "alias": "accentColor"; "required": false; }; }, { "itemSelect": "itemSelect"; "collapsedChange": "collapsedChange"; "searchChange": "searchChange"; "darkModeChange": "darkModeChange"; "userAction": "userAction"; }, ["headerTemplate", "subheaderTemplate", "menuTemplate", "footerTemplate"], never, true, never>;
}

interface SicTab {
    id: string;
    label: string;
    disabled?: boolean;
}
declare class SicTabsComponent {
    tabs: SicTab[];
    activeId?: string;
    activeIdChange: EventEmitter<string>;
    readonly hostClass = true;
    selectTab(tab: SicTab): void;
    handleKeydown(event: KeyboardEvent, index: number): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<SicTabsComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<SicTabsComponent, "sic-tabs", never, { "tabs": { "alias": "tabs"; "required": false; }; "activeId": { "alias": "activeId"; "required": false; }; }, { "activeIdChange": "activeIdChange"; }, never, ["*"], true, never>;
}

interface SicStepperStep {
    label: string;
    description?: string;
    /** Shows the built-in "Skip" nav button while this step is active. */
    optional?: boolean;
    /** Prevents jumping to this step by clicking its indicator. */
    disabled?: boolean;
}

type SicStepperOrientation = 'horizontal' | 'vertical';
/**
 * Step indicator + built-in Previous/Skip/Next/Finish nav, horizontal or vertical. Step *content*
 * is left to you (like sic-tabs) — put whatever you want to show for `activeIndex` as plain
 * `<ng-content>`, e.g. an `@switch (activeIndex)`.
 */
declare class SicStepperComponent {
    private readonly sicConfig;
    private readonly cdr;
    steps: SicStepperStep[];
    activeIndex: number;
    orientation: SicStepperOrientation;
    /** Hides the built-in Previous/Skip/Next/Finish row — drive navigation yourself via `goTo()`/`goToPrevious()`/`goToNext()`/`skipStep()`/`finishStepper()`. */
    showNav: boolean;
    /** Fires whenever the active step changes — Previous/Next/Skip clicks, or clicking a step indicator directly. */
    activeIndexChange: EventEmitter<number>;
    /** Fires (alongside activeIndexChange) specifically when the "Skip" button is clicked, with the index of the step that was skipped. */
    skip: EventEmitter<number>;
    /** Fires when "Finish" is clicked on the last step. Doesn't change activeIndex on its own. */
    finish: EventEmitter<void>;
    readonly hostClass = true;
    get isVertical(): boolean;
    get isFirst(): boolean;
    get isLast(): boolean;
    get currentStep(): SicStepperStep | undefined;
    get previousText(): string;
    get nextText(): string;
    get skipText(): string;
    get finishText(): string;
    stepState(index: number): 'complete' | 'active' | 'upcoming';
    goTo(index: number): void;
    goToPrevious(): void;
    goToNext(): void;
    skipStep(): void;
    finishStepper(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<SicStepperComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<SicStepperComponent, "sic-stepper", never, { "steps": { "alias": "steps"; "required": false; }; "activeIndex": { "alias": "activeIndex"; "required": false; }; "orientation": { "alias": "orientation"; "required": false; }; "showNav": { "alias": "showNav"; "required": false; }; }, { "activeIndexChange": "activeIndexChange"; "skip": "skip"; "finish": "finish"; }, never, ["*"], true, never>;
}

interface SicTimelineItem {
    title?: string;
    date?: string;
    description?: string;
    /** Accent color for this entry's circle/text — any CSS color value. */
    color?: string;
    /** Shown inside the circle instead of the 1-based index. */
    icon?: string;
}

type SicTimelineOrientation = 'horizontal' | 'vertical';
type SicTimelineSide = 'start' | 'end';
/** Template context handed to a custom `<ng-template #itemTemplate let-item let-index="index" let-side="side">` entry. */
interface SicTimelineItemContext<T> {
    $implicit: T;
    index: number;
    side: SicTimelineSide;
}
/**
 * A vertical or horizontal timeline. `[alternate]` (default true) zigzags entries across the
 * axis line, same as the reference "history" layouts; set it to false to keep every entry on one
 * side instead. Provide `<ng-template #itemTemplate>` to fully customize how each entry renders —
 * otherwise a plain date/title/description block is used.
 */
declare class SicTimelineComponent<T extends SicTimelineItem = SicTimelineItem> {
    items: T[];
    orientation: SicTimelineOrientation;
    /** Zigzag entries across the axis (default) instead of keeping them all on one side. */
    alternate: boolean;
    /** Which side item 0 renders on. With `alternate`, every following item flips; without it, every item stays on this side. */
    side: SicTimelineSide;
    /** `<ng-template #itemTemplate let-item let-index="index" let-side="side">` overrides how each entry renders. */
    itemTemplate?: TemplateRef<SicTimelineItemContext<T>>;
    readonly hostClass = true;
    get isHorizontal(): boolean;
    get hideStart(): boolean;
    get hideEnd(): boolean;
    contentSide(index: number): SicTimelineSide;
    trackByFn: (_index: number, item: T) => unknown;
    static ɵfac: i0.ɵɵFactoryDeclaration<SicTimelineComponent<any>, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<SicTimelineComponent<any>, "sic-timeline", never, { "items": { "alias": "items"; "required": false; }; "orientation": { "alias": "orientation"; "required": false; }; "alternate": { "alias": "alternate"; "required": false; }; "side": { "alias": "side"; "required": false; }; }, {}, ["itemTemplate"], never, true, never>;
}

interface SicBreadcrumbItem {
    label: string;
    link?: string;
}
declare class SicBreadcrumbComponent {
    items: SicBreadcrumbItem[];
    separator: string;
    itemClick: EventEmitter<SicBreadcrumbItem>;
    readonly hostClass = true;
    static ɵfac: i0.ɵɵFactoryDeclaration<SicBreadcrumbComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<SicBreadcrumbComponent, "sic-breadcrumb", never, { "items": { "alias": "items"; "required": false; }; "separator": { "alias": "separator"; "required": false; }; }, { "itemClick": "itemClick"; }, never, never, true, never>;
}

/** 'BE' = พุทธศักราช (CE year + 543), 'CE' = คริสต์ศักราช. Storage/output dates are always real (CE) dates — this only changes the year shown to the user. */
type SicCalendarEra = 'BE' | 'CE';
type SicCalendarView = 'grid' | 'list';
/** Who observes the holiday — drives the default icon/color when the entry doesn't set its own. */
type SicCalendarHolidaySource = 'office' | 'government' | 'bank' | 'other';
interface SicCalendarEvent {
    id?: string | number;
    /** The day this task falls on. */
    date: Date | string;
    title: string;
    /** CSS color for the task's dot/line. Defaults to the theme primary color. */
    color?: string;
    /** Short text/emoji rendered next to the title (e.g. an icon glyph). */
    icon?: string;
    description?: string;
}
interface SicCalendarHoliday {
    id?: string | number;
    /** The day this holiday falls on. */
    date: Date | string;
    title: string;
    source?: SicCalendarHolidaySource;
    /** CSS color for the badge. Defaults to a color based on `source`. */
    color?: string;
    /** Short text/emoji for the badge. Defaults to an icon based on `source`. */
    icon?: string;
}
interface SicCalendarDayCell {
    date: Dayjs;
    inMonth: boolean;
    isToday: boolean;
    isSelected: boolean;
    tasks: SicCalendarEvent[];
    holidays: SicCalendarHoliday[];
}
type SicCalendarTaskLine = {
    task: SicCalendarEvent;
    moreCount?: undefined;
} | {
    task?: undefined;
    moreCount: number;
};
declare class SicCalendarComponent implements OnInit, OnDestroy {
    private readonly sicConfig;
    selected: Date | string | null;
    weekStartsOn: 0 | 1;
    /** Tasks — shown as icon+title lines (one per line, ellipsized) inside each day. */
    tasks: SicCalendarEvent[];
    /** Holidays — shown as a cluster of overlapping circular badges inside each day. */
    holidays: SicCalendarHoliday[];
    era: SicCalendarEra;
    /** Show/hide the พ.ศ./ค.ศ. toggle button in the toolbar. Default true. */
    eraSwitcher: boolean;
    view: SicCalendarView;
    /** dayjs locale code for month/weekday names. Import the matching `dayjs/locale/<code>`
     *  package yourself before use — dayjs falls back to English for unregistered locales. */
    locale: string;
    /** Max task lines shown per day cell (grid view) before the last line collapses into "ดูเพิ่มเติม". */
    maxVisibleTasks: number;
    selectedChange: EventEmitter<Date>;
    eraChange: EventEmitter<SicCalendarEra>;
    viewChange: EventEmitter<SicCalendarView>;
    dateClick: EventEmitter<{
        date: Date;
        tasks: SicCalendarEvent[];
        holidays: SicCalendarHoliday[];
    }>;
    eventClick: EventEmitter<SicCalendarEvent>;
    holidayClick: EventEmitter<SicCalendarHoliday>;
    /** Fires whenever the viewed month changes (prev/next/today nav) with the first day of the new month. */
    monthChange: EventEmitter<Date>;
    readonly hostClass = true;
    get compactHostClass(): boolean;
    get noEventsText(): string;
    private readonly elementRef;
    private readonly platformId;
    private readonly cdr;
    private resizeObserver?;
    viewDate: dayjs.Dayjs;
    /**
     * True once the calendar's own rendered width drops below `COMPACT_MAX_WIDTH`
     * — measured with a `ResizeObserver` on the host rather than a CSS media/container
     * query so it works reliably regardless of container-query support, and reflects
     * the calendar's actual embedded width rather than the browser window's.
     */
    compact: boolean;
    sidebarOpen: boolean;
    sidebarKind: 'holiday' | 'task' | null;
    sidebarDate: Dayjs | null;
    sidebarHolidays: SicCalendarHoliday[];
    sidebarTasks: SicCalendarEvent[];
    monthYearPickerOpen: boolean;
    get monthLabel(): string;
    /** Abbreviated weekday labels (mobile). See `orderedWeekdayFullLabels` for the desktop variant. */
    get orderedWeekdayLabels(): string[];
    /** Full weekday names — shown instead of `orderedWeekdayLabels` above a CSS breakpoint (desktop). */
    get orderedWeekdayFullLabels(): string[];
    get dayCells(): SicCalendarDayCell[];
    get agendaDays(): SicCalendarDayCell[];
    get monthOptions(): {
        value: number;
        label: string;
    }[];
    /** A 21-year window centered on the currently viewed year. */
    get yearOptions(): number[];
    yearOptionLabel(year: number): string;
    get sidebarTitle(): string;
    private get selectedDate();
    private tasksForDate;
    private holidaysForDate;
    visibleHolidayBadges(dayHolidays: SicCalendarHoliday[]): SicCalendarHoliday[];
    hiddenHolidayCount(dayHolidays: SicCalendarHoliday[]): number;
    getTaskLines(dayTasks: SicCalendarEvent[]): SicCalendarTaskLine[];
    holidayIcon(holiday: SicCalendarHoliday): string;
    holidayColor(holiday: SicCalendarHoliday): string;
    holidaySourceLabel(holiday: SicCalendarHoliday): string;
    eventTooltip(event: SicCalendarEvent): string;
    selectDate(cell: SicCalendarDayCell): void;
    handleEventClick(nativeEvent: MouseEvent, event: SicCalendarEvent): void;
    handleHolidayClick(holiday: SicCalendarHoliday): void;
    openHolidaySidebar(nativeEvent: MouseEvent, date: Dayjs, dayHolidays: SicCalendarHoliday[]): void;
    openTaskSidebar(nativeEvent: MouseEvent, date: Dayjs, dayTasks: SicCalendarEvent[]): void;
    closeSidebar(): void;
    toggleMonthYearPicker(nativeEvent: MouseEvent): void;
    selectPickerMonth(month: number): void;
    selectPickerYear(year: number): void;
    handleDocumentClick(event: MouseEvent): void;
    ngOnInit(): void;
    ngOnDestroy(): void;
    prevMonth(): void;
    nextMonth(): void;
    goToToday(): void;
    private setViewDate;
    toggleEra(): void;
    setView(view: SicCalendarView): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<SicCalendarComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<SicCalendarComponent, "sic-calendar", never, { "selected": { "alias": "selected"; "required": false; }; "weekStartsOn": { "alias": "weekStartsOn"; "required": false; }; "tasks": { "alias": "tasks"; "required": false; }; "holidays": { "alias": "holidays"; "required": false; }; "era": { "alias": "era"; "required": false; }; "eraSwitcher": { "alias": "eraSwitcher"; "required": false; }; "view": { "alias": "view"; "required": false; }; "locale": { "alias": "locale"; "required": false; }; "maxVisibleTasks": { "alias": "maxVisibleTasks"; "required": false; }; }, { "selectedChange": "selectedChange"; "eraChange": "eraChange"; "viewChange": "viewChange"; "dateClick": "dateClick"; "eventClick": "eventClick"; "holidayClick": "holidayClick"; "monthChange": "monthChange"; }, never, never, true, never>;
}

type SicCodeLanguage = 'typescript' | 'javascript' | 'html' | 'css' | 'json' | 'bash' | 'plaintext';
type SicCodeTokenType = 'keyword' | 'string' | 'comment' | 'number' | 'boolean' | 'function' | 'property' | 'tag' | 'attr' | 'punctuation' | 'text';
interface SicCodeToken {
    text: string;
    type: SicCodeTokenType;
}
/** Tokenizes `code` for syntax highlighting, returning one token array per line (ready for a line-numbered render). Unsupported/`'plaintext'` languages return each line as a single 'text' token. */
declare function tokenizeCode(code: string, language: SicCodeLanguage): SicCodeToken[][];

/**
 * Read-only code block: line numbers (toggleable via `[showLineNumbers]`), a copy-to-clipboard
 * button, and lightweight syntax highlighting (no external dependency) for
 * typescript/javascript/html/css/json/bash — colored close to a typical Prettier-formatted
 * VSCode theme, light and dark.
 */
declare class SicCodeComponent implements OnChanges {
    private readonly sicConfig;
    private readonly isBrowser;
    private readonly cdr;
    code: string;
    language: SicCodeLanguage;
    showLineNumbers: boolean;
    showCopyButton: boolean;
    readonly hostClass = true;
    lines: SicCodeToken[][];
    justCopied: boolean;
    private copyResetTimer?;
    get copyText(): string;
    get copiedText(): string;
    ngOnChanges(changes: SimpleChanges): void;
    copy(): Promise<void>;
    static ɵfac: i0.ɵɵFactoryDeclaration<SicCodeComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<SicCodeComponent, "sic-code", never, { "code": { "alias": "code"; "required": false; }; "language": { "alias": "language"; "required": false; }; "showLineNumbers": { "alias": "showLineNumbers"; "required": false; }; "showCopyButton": { "alias": "showCopyButton"; "required": false; }; }, {}, never, never, true, never>;
}

/** One segment of a row's bar — rows can have more than one, non-overlapping or not, to represent phases (e.g. "planning" then "in progress"). */
interface SicCalendarTimelinePhase {
    id?: string | number;
    label?: string;
    description?: string;
    start: Date | string;
    end: Date | string;
    /** CSS color for the bar. Defaults to the theme primary color. */
    color?: string;
    avatarUrl?: string;
}
interface SicCalendarTimelineRow<T = unknown> {
    id: string | number;
    label: string;
    avatarUrl?: string;
    /** 0-100. Shown in the label column's "Progress" cell when set. */
    progress?: number;
    phases: SicCalendarTimelinePhase[];
    /** Arbitrary passthrough data your own #labelTemplate/#phaseTemplate can read. */
    data?: T;
}

/** 'BE' = พุทธศักราช (CE year + 543), 'CE' = คริสต์ศักราช. Storage/output dates are always real (CE) dates — this only changes the year shown to the user. */
type SicCalendarTimelineEra = 'BE' | 'CE';
type SicCalendarTimelineViewMode = 'day' | 'week' | 'month';
/** Template context for `#labelTemplate`: `let-row let-index="index"`. */
interface SicCalendarTimelineLabelContext<T> {
    $implicit: SicCalendarTimelineRow<T>;
    index: number;
}
/** Template context for `#phaseTemplate`: `let-phase let-row="row" let-index="index"`. */
interface SicCalendarTimelinePhaseContext<T> {
    $implicit: SicCalendarTimelinePhase;
    row: SicCalendarTimelineRow<T>;
    index: number;
}
interface SicCalendarTimelineColumn {
    start: Dayjs;
    end: Dayjs;
    label: string;
    sublabel?: string;
    isWeekend: boolean;
    isToday: boolean;
}
interface SicCalendarTimelineGroup {
    label: string;
    span: number;
}
interface SicCalendarTimelinePhasePosition {
    phase: SicCalendarTimelinePhase;
    colStart: number;
    colSpan: number;
}
interface SicCalendarTimelineViewModeOption {
    value: SicCalendarTimelineViewMode;
    label: string;
}
/**
 * Gantt-style timeline: a collapsible row-label column on the left, and a day/week/month grid on
 * the right where each row's `phases` render as positioned bars. `[startDate]`/`[endDate]` set the
 * visible range; `[viewMode]` controls the column granularity. Header/year formatting goes through
 * dayjs — set `[locale]` (import the matching `dayjs/locale/<code>` package yourself, e.g.
 * `dayjs/locale/th`, for localized weekday/month names) and `[era]` ('BE' shows พ.ศ., 'CE' shows
 * ค.ศ., default from `SIC_CONFIG.era`). Customize row rendering via `#labelTemplate` and bar
 * rendering via `#phaseTemplate`.
 */
declare class SicCalendarTimelineComponent<T = unknown> {
    private readonly sicConfig;
    private syncingScroll;
    items: SicCalendarTimelineRow<T>[];
    startDate: Date | string;
    endDate: Date | string;
    viewMode: SicCalendarTimelineViewMode;
    /** Which view-mode choices the built-in `[showViewModeToggle]` popover offers, in order. Default: all three. */
    viewModeOptions: SicCalendarTimelineViewMode[];
    /** Shows/hides the built-in day/week/month switcher (a `sic-popover` above the grid). Default: true. */
    showViewModeToggle: boolean;
    era: SicCalendarTimelineEra;
    /** dayjs locale code for weekday/month names. Import the matching `dayjs/locale/<code>`
     *  package yourself before use (e.g. `import 'dayjs/locale/th';` then `locale="th"`) — dayjs
     *  falls back to English for unregistered locales. */
    locale: string;
    /** Shows/hides the row-label column (bindable with `[(showLabelColumn)]`). */
    showLabelColumn: boolean;
    /** Caps the row area's height (any CSS length) and makes it scroll — both label rows and the
     *  timeline grid scroll together — instead of growing unbounded with the item count. */
    maxHeight: string | null;
    showLabelColumnChange: EventEmitter<boolean>;
    viewModeChange: EventEmitter<SicCalendarTimelineViewMode>;
    phaseClick: EventEmitter<{
        row: SicCalendarTimelineRow<T>;
        phase: SicCalendarTimelinePhase;
    }>;
    rowClick: EventEmitter<SicCalendarTimelineRow<T>>;
    private labelsPaneRef?;
    private gridPaneRef?;
    /** `<ng-template #labelTemplate let-row let-index="index">` overrides the row-label cell. */
    labelTemplate?: TemplateRef<SicCalendarTimelineLabelContext<T>>;
    /** `<ng-template #phaseTemplate let-phase let-row="row" let-index="index">` overrides how each phase bar renders. */
    phaseTemplate?: TemplateRef<SicCalendarTimelinePhaseContext<T>>;
    readonly hostClass = true;
    get noItemsText(): string;
    get viewModeLabelText(): string;
    get viewModeItems(): SicCalendarTimelineViewModeOption[];
    get activeViewModeLabel(): string;
    private viewModeLabel;
    private get start();
    private get end();
    get columns(): SicCalendarTimelineColumn[];
    /** Month/year super-header spanning the day/week columns underneath it — not shown in month view, where each column already is a month. */
    get groups(): SicCalendarTimelineGroup[];
    get gridTemplateColumns(): string;
    phasePositions(row: SicCalendarTimelineRow<T>): SicCalendarTimelinePhasePosition[];
    trackByFn: (_index: number, row: SicCalendarTimelineRow<T>) => unknown;
    toggleLabelColumn(): void;
    selectViewMode(option: SicCalendarTimelineViewModeOption): void;
    handlePhaseClick(row: SicCalendarTimelineRow<T>, phase: SicCalendarTimelinePhase): void;
    handleRowClick(row: SicCalendarTimelineRow<T>): void;
    /** Keeps the label column's rows and the timeline grid's rows scrolled to the same vertical
     *  offset — they're two independently-scrollable panes (only the grid pane scrolls horizontally). */
    onLabelsScroll(): void;
    onGridScroll(): void;
    private syncScroll;
    static ɵfac: i0.ɵɵFactoryDeclaration<SicCalendarTimelineComponent<any>, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<SicCalendarTimelineComponent<any>, "sic-calendar-timeline", never, { "items": { "alias": "items"; "required": false; }; "startDate": { "alias": "startDate"; "required": false; }; "endDate": { "alias": "endDate"; "required": false; }; "viewMode": { "alias": "viewMode"; "required": false; }; "viewModeOptions": { "alias": "viewModeOptions"; "required": false; }; "showViewModeToggle": { "alias": "showViewModeToggle"; "required": false; }; "era": { "alias": "era"; "required": false; }; "locale": { "alias": "locale"; "required": false; }; "showLabelColumn": { "alias": "showLabelColumn"; "required": false; }; "maxHeight": { "alias": "maxHeight"; "required": false; }; }, { "showLabelColumnChange": "showLabelColumnChange"; "viewModeChange": "viewModeChange"; "phaseClick": "phaseClick"; "rowClick": "rowClick"; }, ["labelTemplate", "phaseTemplate"], never, true, never>;
}

type SicImageMode = 'sync' | 'async';
type SicImageAsyncStrategy = 'progressive' | 'skeleton';
declare class SicImageComponent implements OnChanges {
    src: string;
    alt: string;
    fallback: string;
    loading: 'lazy' | 'eager';
    rounded: 'none' | 'sm' | 'md' | 'lg' | 'full';
    /** Grayscale + dimmed at rest, full color on hover — a common "trust bar"/partner-logo touch. */
    grayscaleHover: boolean;
    width?: number | string;
    height?: number | string;
    /** `sync` renders the `<img>` immediately. `async` defers reveal until the full image finishes loading. */
    mode: SicImageMode;
    /**
     * Only applies when `mode="async"`.
     * - `progressive`: show a small/blurred placeholder first, then swap to the full image once it loads.
     * - `skeleton`: show a shimmering placeholder until the full image loads, then reveal it.
     */
    asyncStrategy: SicImageAsyncStrategy;
    /** Explicit low-res URL for the `progressive` strategy. Defaults to `src` requested at `lowResWidth`. */
    lowResSrc: string;
    /** Width requested for the auto-generated low-res placeholder when `lowResSrc` isn't set. */
    lowResWidth: number;
    /** Append `width`/`height` as query params onto the resolved image URL, for CDNs that resize on request. */
    appendSizeToUrl: boolean;
    widthParam: string;
    heightParam: string;
    readonly hostClass = true;
    get isGrayscaleHover(): boolean;
    errored: boolean;
    loaded: boolean;
    private lowResErrored;
    ngOnChanges(changes: SimpleChanges): void;
    get resolvedSrc(): string;
    get resolvedLowResSrc(): string;
    get hostWidthStyle(): string | undefined;
    get hostHeightStyle(): string | undefined;
    handleError(): void;
    handleLowResError(): void;
    handleLoad(): void;
    private buildUrl;
    static ɵfac: i0.ɵɵFactoryDeclaration<SicImageComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<SicImageComponent, "sic-image", never, { "src": { "alias": "src"; "required": true; }; "alt": { "alias": "alt"; "required": false; }; "fallback": { "alias": "fallback"; "required": false; }; "loading": { "alias": "loading"; "required": false; }; "rounded": { "alias": "rounded"; "required": false; }; "grayscaleHover": { "alias": "grayscaleHover"; "required": false; }; "width": { "alias": "width"; "required": false; }; "height": { "alias": "height"; "required": false; }; "mode": { "alias": "mode"; "required": false; }; "asyncStrategy": { "alias": "asyncStrategy"; "required": false; }; "lowResSrc": { "alias": "lowResSrc"; "required": false; }; "lowResWidth": { "alias": "lowResWidth"; "required": false; }; "appendSizeToUrl": { "alias": "appendSizeToUrl"; "required": false; }; "widthParam": { "alias": "widthParam"; "required": false; }; "heightParam": { "alias": "heightParam"; "required": false; }; }, {}, never, never, true, never>;
}

interface SicImageSliderItem<T = unknown> {
    id?: string | number;
    imageUrl: string;
    alt?: string;
    caption?: string;
    data?: T;
}

/** Template context for `#slideTemplate`: `let-item let-index="index"`. Rendered on top of the slide's image — use it to add captions, badges, buttons, etc. */
interface SicImageSliderContext<T> {
    $implicit: SicImageSliderItem<T>;
    index: number;
}
/**
 * A looping image carousel: prev/next arrows (`[showArrows]`, hideable), position dots
 * (`[showDots]`), optional auto-advance (`[autoSlide]` + `[autoSlideInterval]`, paused on hover),
 * and a `#slideTemplate` slot to overlay custom markup on each slide's image. Reaching past the
 * last slide (via arrows, dots, or auto-slide) wraps back to the first, and vice versa, unless
 * `[loop]` is set false.
 */
declare class SicImageSliderComponent<T = unknown> implements OnChanges, OnDestroy {
    private readonly sicConfig;
    private readonly isBrowser;
    private readonly cdr;
    items: SicImageSliderItem<T>[];
    activeIndex: number;
    /** Width/height ratio for the slider, as a CSS `aspect-ratio` value (e.g. `'16 / 9'`, `'1 / 1'`). Width always fills the container; height is derived from this ratio. Default: `'16 / 9'`. */
    aspectRatio: string;
    /**
     * CSS `min-height` value (e.g. `'16rem'`) — a floor under the `aspectRatio`-computed height, so a
     * wide ratio (e.g. `'21 / 9'`) doesn't collapse into a too-short box on a narrow viewport where
     * overlaid content (via `#slideTemplate`) would otherwise overflow it. Unset by default.
     */
    minHeight?: string;
    /** Corner radius, matching sic-image's scale. Default: `'lg'`. */
    rounded: 'none' | 'sm' | 'md' | 'lg' | 'full';
    /** Shows/hides the prev/next arrow buttons. Default: true. */
    showArrows: boolean;
    /** Shows/hides the position dots. Default: true. */
    showDots: boolean;
    /** Wraps from the last slide back to the first (and vice versa) instead of stopping. Default: true. */
    loop: boolean;
    /** Automatically advances to the next slide. Default: false. */
    autoSlide: boolean;
    /** Milliseconds between auto-slide advances. Default: 4000. */
    autoSlideInterval: number;
    /** Pauses auto-slide while the pointer is over the slider. Default: true. */
    pauseOnHover: boolean;
    /**
     * Wraps `#slideTemplate`'s projected content in an absolutely-positioned dark gradient scrim
     * (heavier at the bottom), so light overlay text/buttons stay readable regardless of the
     * underlying slide image — set this instead of hand-rolling the same overlay CSS outside.
     */
    overlay: boolean;
    activeIndexChange: EventEmitter<number>;
    /** Emits the new index and item whenever the active slide changes, for any reason (arrows, dots, or auto-slide). */
    slideChange: EventEmitter<{
        index: number;
        item: SicImageSliderItem<T>;
    }>;
    /** Emits whenever the last slide becomes active. */
    slideEnd: EventEmitter<void>;
    /** `<ng-template #slideTemplate let-item let-index="index">` overlays custom markup on top of each slide's image. */
    slideTemplate?: TemplateRef<SicImageSliderContext<T>>;
    readonly hostClass = true;
    get aspectRatioVar(): string;
    get minHeightVar(): string;
    private timer?;
    private hoverPaused;
    ngOnChanges(changes: SimpleChanges): void;
    ngOnDestroy(): void;
    get noItemsText(): string;
    trackByFn: (index: number, item: SicImageSliderItem<T>) => unknown;
    next(): void;
    prev(): void;
    goTo(index: number): void;
    onMouseEnter(): void;
    onMouseLeave(): void;
    private restartAutoSlide;
    private stopAutoSlide;
    static ɵfac: i0.ɵɵFactoryDeclaration<SicImageSliderComponent<any>, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<SicImageSliderComponent<any>, "sic-image-slider", never, { "items": { "alias": "items"; "required": false; }; "activeIndex": { "alias": "activeIndex"; "required": false; }; "aspectRatio": { "alias": "aspectRatio"; "required": false; }; "minHeight": { "alias": "minHeight"; "required": false; }; "rounded": { "alias": "rounded"; "required": false; }; "showArrows": { "alias": "showArrows"; "required": false; }; "showDots": { "alias": "showDots"; "required": false; }; "loop": { "alias": "loop"; "required": false; }; "autoSlide": { "alias": "autoSlide"; "required": false; }; "autoSlideInterval": { "alias": "autoSlideInterval"; "required": false; }; "pauseOnHover": { "alias": "pauseOnHover"; "required": false; }; "overlay": { "alias": "overlay"; "required": false; }; }, { "activeIndexChange": "activeIndexChange"; "slideChange": "slideChange"; "slideEnd": "slideEnd"; }, ["slideTemplate"], never, true, never>;
}

/**
 * A compact album-style audio player card: cover art, title/subtitle, a clickable waveform
 * (seeks on click, fills to show playback progress), and transport controls (prev, play/pause,
 * next). Wraps a native `<audio>` element internally.
 */
declare class SicSoundPlayerComponent {
    src: string;
    title: string;
    subtitle?: string;
    coverUrl?: string;
    /** Short genre/tag pill shown under the cover art (e.g. `'Synthwave'`). */
    genre?: string;
    /** Pre-formatted play-count text shown under the genre pill (e.g. `'1.2M plays'`). */
    plays?: string;
    autoplay: boolean;
    loop: boolean;
    muted: boolean;
    /** Number of bars drawn in the waveform. Default: 48. */
    barsCount: number;
    play: EventEmitter<void>;
    pause: EventEmitter<void>;
    ended: EventEmitter<void>;
    timeUpdate: EventEmitter<{
        currentTime: number;
        duration: number;
    }>;
    previousTrack: EventEmitter<void>;
    nextTrack: EventEmitter<void>;
    private audioRef?;
    private waveformRef?;
    readonly hostClass = true;
    playing: boolean;
    currentTime: number;
    duration: number;
    get bars(): number[];
    get progress(): number;
    get activeBarCount(): number;
    get formattedCurrentTime(): string;
    get formattedDuration(): string;
    togglePlay(): void;
    onPlay(): void;
    onPause(): void;
    onEnded(): void;
    onLoadedMetadata(): void;
    onTimeUpdate(): void;
    onWaveformClick(event: MouseEvent): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<SicSoundPlayerComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<SicSoundPlayerComponent, "sic-sound-player", never, { "src": { "alias": "src"; "required": true; }; "title": { "alias": "title"; "required": false; }; "subtitle": { "alias": "subtitle"; "required": false; }; "coverUrl": { "alias": "coverUrl"; "required": false; }; "genre": { "alias": "genre"; "required": false; }; "plays": { "alias": "plays"; "required": false; }; "autoplay": { "alias": "autoplay"; "required": false; }; "loop": { "alias": "loop"; "required": false; }; "muted": { "alias": "muted"; "required": false; }; "barsCount": { "alias": "barsCount"; "required": false; }; }, { "play": "play"; "pause": "pause"; "ended": "ended"; "timeUpdate": "timeUpdate"; "previousTrack": "previousTrack"; "nextTrack": "nextTrack"; }, never, never, true, never>;
}

declare class SicVideoPlayerComponent {
    private readonly sicConfig;
    src: string;
    /** Shown in place of the video until playback starts — without one, the browser has nothing to render but a black frame before the first play. */
    poster?: string;
    autoplay: boolean;
    loop: boolean;
    muted: boolean;
    /** Width/height ratio for the player, as a CSS `aspect-ratio` value (e.g. `'16 / 9'`, `'4 / 3'`). Width always fills the container; height is derived from this ratio. Default: `'16 / 9'`. */
    aspectRatio: string;
    videoRef?: ElementRef<HTMLVideoElement>;
    readonly hostClass = true;
    get aspectRatioVar(): string;
    playing: boolean;
    get playLabel(): string;
    /**
     * When a poster is set, skip the browser's default eager video fetch so it can't race ahead and
     * swap the poster for a decoded frame before the user has actually pressed play. Without a
     * poster there's nothing to preview anyway, so 'metadata' is used to at least get a duration.
     */
    get preload(): 'none' | 'metadata';
    togglePlay(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<SicVideoPlayerComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<SicVideoPlayerComponent, "sic-video-player", never, { "src": { "alias": "src"; "required": true; }; "poster": { "alias": "poster"; "required": false; }; "autoplay": { "alias": "autoplay"; "required": false; }; "loop": { "alias": "loop"; "required": false; }; "muted": { "alias": "muted"; "required": false; }; "aspectRatio": { "alias": "aspectRatio"; "required": false; }; }, {}, never, never, true, never>;
}

/** Template context handed to a custom `<ng-template #itemTemplate let-item let-index="index">` card. */
interface SicMasonryItemContext<T> {
    $implicit: T;
    index: number;
}
/** One rendered card: `item` plus its position in the original (unsplit) `items`/lazy-loaded array. */
interface SicMasonryEntry<T> {
    item: T;
    index: number;
}
interface SicMasonryLoadPayload {
    pageNo: number;
    pageSize: number;
}
/** Emitted when `isLazy` is true and the sentinel at the bottom of the grid scrolls into view. Call `items.update(...)` with the next page. */
interface SicMasonryLoadEvent<T = unknown> extends SicMasonryLoadPayload {
    items: {
        update: (items: T[]) => void;
    };
}
/**
 * Pinterest-style masonry grid. Items are distributed into column buckets — greedily, each item
 * (in original array order) goes into whichever column currently has the least accumulated height,
 * exactly like Pinterest's own layout — so tall/short cards balance out instead of the last column
 * running long. Heights are measured from the real rendered cards, so an initial left-to-right
 * round-robin guess is used until that measurement is available (usually a single animation frame).
 * Pass `[items]` for a plain static grid, or set `[isLazy]="true"` and handle `(loadMore)` to fetch
 * more pages as the user scrolls near the bottom. Provide `<ng-template #itemTemplate>` to fully
 * customize how each card renders, and listen to `(itemClick)` for per-card clicks.
 */
declare class SicMasonryComponent<T = unknown> implements OnChanges, AfterViewInit, OnDestroy {
    private readonly sicConfig;
    private readonly isBrowser;
    private readonly cdr;
    items: T[];
    cols: number;
    /** Breakpoint → column count, e.g. { sm: 1, md: 2, lg: 4 } */
    colsBreakpoints: Record<'sm' | 'md' | 'lg', number> | null;
    gap: string;
    /** When true, `items` is ignored — the component loads its own pages via `(loadMore)`, starting automatically on init. */
    isLazy: boolean;
    pageSize: number;
    trackBy?: (index: number, item: T) => unknown;
    loadMore: EventEmitter<SicMasonryLoadEvent<T>>;
    /** Emits the clicked item (and its index in `items`/the lazy-loaded array). */
    itemClick: EventEmitter<T>;
    /** `<ng-template #itemTemplate let-item let-index="index">` overrides how each card renders. */
    itemTemplate?: TemplateRef<SicMasonryItemContext<T>>;
    private readonly sentinelRef?;
    private itemEls?;
    loadingMore: boolean;
    hasMore: boolean;
    /** Column buckets actually rendered — index 0 is the leftmost column. */
    columns: SicMasonryEntry<T>[][];
    private loadedItems;
    private pageNo;
    private observer?;
    private resizeTimer?;
    private lastRenderedCols;
    get dataset(): T[];
    get noItemsText(): string;
    get loadingMoreText(): string;
    readonly hostClass = true;
    get responsive(): boolean;
    get colsVar(): number;
    get gapVar(): string;
    get colsSm(): number;
    get colsMd(): number;
    get colsLg(): number;
    /** The column count actually in effect right now, resolved from `colsBreakpoints` + the current viewport width, matching the same sm/md breakpoints (768/1024px) the rest of the library uses. */
    get effectiveCols(): number;
    onWindowResize(): void;
    ngOnChanges(changes: SimpleChanges): void;
    ngAfterViewInit(): void;
    ngOnDestroy(): void;
    trackByFn: (index: number, entry: SicMasonryEntry<T>) => unknown;
    handleItemClick(entry: SicMasonryEntry<T>): void;
    /** Left-to-right round-robin guess, used until real card heights are measured (and as the permanent layout if measurement isn't available, e.g. during SSR). */
    private rebuildNaiveColumns;
    private scheduleRelayout;
    /** Re-buckets items using the real rendered height of each card (see computeMasonryColumns). No-ops if nothing has a measurable height yet (e.g. still hidden/off-screen). */
    private relayoutFromMeasuredHeights;
    private loadNextPage;
    private applyLoadedItems;
    static ɵfac: i0.ɵɵFactoryDeclaration<SicMasonryComponent<any>, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<SicMasonryComponent<any>, "sic-masonry", never, { "items": { "alias": "items"; "required": false; }; "cols": { "alias": "cols"; "required": false; }; "colsBreakpoints": { "alias": "colsBreakpoints"; "required": false; }; "gap": { "alias": "gap"; "required": false; }; "isLazy": { "alias": "isLazy"; "required": false; }; "pageSize": { "alias": "pageSize"; "required": false; }; "trackBy": { "alias": "trackBy"; "required": false; }; }, { "loadMore": "loadMore"; "itemClick": "itemClick"; }, ["itemTemplate"], never, true, never>;
}

interface SicDragDropList<T = unknown> {
    /** Unique across every list rendered on the page — used as the underlying `cdkDropList` id so items can be dropped between lists. */
    id: string;
    title?: string;
    items: T[];
}
/** Template context handed to a custom `<ng-template #itemTemplate let-item let-index="index" let-listId="listId">` card. */
interface SicDragDropItemContext<T> {
    $implicit: T;
    index: number;
    listId: string;
}
/** Template context handed to a custom `<ng-template #columnHeaderTemplate let-list>` column header. */
interface SicDragDropColumnHeaderContext<T> {
    $implicit: SicDragDropList<T>;
}
interface SicDragDropMoveEvent<T = unknown> {
    item: T;
    previousListId: string;
    previousIndex: number;
    currentListId: string;
    currentIndex: number;
}

/**
 * Reorder items within a list, or drag them between multiple lists (kanban-style) — built on
 * `@angular/cdk/drag-drop`. Pass a single-element `[lists]` (or the `[items]` shorthand) for plain
 * reordering, or several lists to allow moving cards between columns. Customize card/column-header
 * rendering via `<ng-template #itemTemplate>` / `<ng-template #columnHeaderTemplate>`.
 */
declare class SicDragDropComponent<T = unknown> {
    private readonly sicConfig;
    private readonly cdr;
    /** Back-compat shorthand: a single unnamed reorderable list, used when `lists` isn't given. */
    items: T[];
    lists: SicDragDropList<T>[];
    trackBy?: (index: number, item: T) => unknown;
    /** When true, only a dedicated ⠿ handle starts a drag instead of the whole card. */
    showDragHandle: boolean;
    itemMoved: EventEmitter<SicDragDropMoveEvent<T>>;
    /** `<ng-template #itemTemplate let-item let-index="index" let-listId="listId">` overrides how each card renders. */
    itemTemplate?: TemplateRef<SicDragDropItemContext<T>>;
    /** `<ng-template #columnHeaderTemplate let-list>` overrides the header above each list/column. */
    columnHeaderTemplate?: TemplateRef<SicDragDropColumnHeaderContext<T>>;
    readonly hostClass = true;
    get resolvedLists(): SicDragDropList<T>[];
    get emptyListText(): string;
    trackByFn: (index: number, item: T) => unknown;
    drop(event: CdkDragDrop<T[]>): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<SicDragDropComponent<any>, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<SicDragDropComponent<any>, "sic-drag-drop", never, { "items": { "alias": "items"; "required": false; }; "lists": { "alias": "lists"; "required": false; }; "trackBy": { "alias": "trackBy"; "required": false; }; "showDragHandle": { "alias": "showDragHandle"; "required": false; }; }, { "itemMoved": "itemMoved"; }, ["itemTemplate", "columnHeaderTemplate"], never, true, never>;
}

interface SicCardStackItem<T = unknown> {
    id?: string | number;
    title?: string;
    description?: string;
    imageUrl?: string;
    /** Small pill shown top-left of the image, e.g. "01". */
    label?: string;
    /** Small pill shown top-right of the image, e.g. "6 min read". */
    meta?: string;
    location?: string;
    data?: T;
}

/** Template context for `#cardTemplate`: `let-item let-index="index" let-position="position"`. */
interface SicCardStackContext<T> {
    $implicit: SicCardStackItem<T>;
    index: number;
    /** 0 = front-most (fully visible) card, increasing toward the back of the stack. */
    position: number;
}
/**
 * A deck of overlapping cards: collapsed into a cascaded stack by default, fanning out on hover
 * (or via `[expanded]`). Clicking any card behind the front one brings it to the front, animating
 * every card's position with a CSS transition (front/back cards keep their DOM identity across
 * reorders via `trackBy`-by-id, so the transition is smooth rather than a re-render jump).
 * Customize card rendering with `#cardTemplate`.
 */
declare class SicCardStackComponent<T = unknown> implements OnChanges {
    private readonly sicConfig;
    items: SicCardStackItem<T>[];
    /** Fans the stack out on hover. Default: true. */
    expandOnHover: boolean;
    /** Set true/false to force the fanned-out state regardless of hover; leave null to follow hover. */
    expanded: boolean | null;
    /** Emits the item index whenever a back card is clicked and becomes the new front card. */
    activeIndexChange: EventEmitter<number>;
    /** Emits on every card click, front or back. */
    cardClick: EventEmitter<{
        item: SicCardStackItem<T>;
        index: number;
    }>;
    /** `<ng-template #cardTemplate let-item let-index="index" let-position="position">` overrides card rendering. */
    cardTemplate?: TemplateRef<SicCardStackContext<T>>;
    readonly hostClass = true;
    private hovered;
    /** stackOrder[position] = item index; position 0 is the front-most card. */
    private stackOrder;
    ngOnChanges(changes: SimpleChanges): void;
    get noItemsText(): string;
    get isExpanded(): boolean;
    onMouseEnter(): void;
    onMouseLeave(): void;
    positionOf(index: number): number;
    zIndexOf(index: number): number;
    trackByFn: (index: number, item: SicCardStackItem<T>) => unknown;
    selectCard(index: number): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<SicCardStackComponent<any>, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<SicCardStackComponent<any>, "sic-card-stack", never, { "items": { "alias": "items"; "required": false; }; "expandOnHover": { "alias": "expandOnHover"; "required": false; }; "expanded": { "alias": "expanded"; "required": false; }; }, { "activeIndexChange": "activeIndexChange"; "cardClick": "cardClick"; }, ["cardTemplate"], never, true, never>;
}

type SicBadgePosition = 'top-right' | 'top-left' | 'bottom-right' | 'bottom-left';
declare class SicBadgeComponent {
    count?: number;
    max: number;
    dot: boolean;
    color: 'primary' | 'success' | 'danger' | 'warning';
    position: SicBadgePosition;
    readonly hostClass = true;
    get displayCount(): string;
    static ɵfac: i0.ɵɵFactoryDeclaration<SicBadgeComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<SicBadgeComponent, "sic-badge", never, { "count": { "alias": "count"; "required": false; }; "max": { "alias": "max"; "required": false; }; "dot": { "alias": "dot"; "required": false; }; "color": { "alias": "color"; "required": false; }; "position": { "alias": "position"; "required": false; }; }, {}, never, ["*"], true, never>;
}

interface SicAvatarItem {
    src?: string;
    name?: string;
}
declare class SicAvatarComponent {
    src?: string;
    name: string;
    size: 'sm' | 'md' | 'lg';
    /** Renders a left-to-right overlapping stack instead of a single avatar — hovering one brings it fully in front of its neighbors. */
    items?: SicAvatarItem[];
    /** Fires on click in single-avatar mode (no `items`). */
    avatarClick: EventEmitter<MouseEvent>;
    /** Fires on click of one avatar within `items`. */
    itemClick: EventEmitter<{
        item: SicAvatarItem;
        index: number;
    }>;
    readonly hostClass = true;
    get isGroup(): boolean;
    get isSm(): boolean;
    get isLg(): boolean;
    errored: boolean;
    private erroredItemIndexes;
    get initials(): string;
    handleError(): void;
    handleHostClick(event: MouseEvent): void;
    itemInitials(item: SicAvatarItem): string;
    itemHasImage(item: SicAvatarItem, index: number): boolean;
    handleItemError(index: number): void;
    handleItemClick(item: SicAvatarItem, index: number, event: MouseEvent): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<SicAvatarComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<SicAvatarComponent, "sic-avatar", never, { "src": { "alias": "src"; "required": false; }; "name": { "alias": "name"; "required": false; }; "size": { "alias": "size"; "required": false; }; "items": { "alias": "items"; "required": false; }; }, { "avatarClick": "avatarClick"; "itemClick": "itemClick"; }, never, never, true, never>;
}

declare class SicCollapseComponent {
    label: string;
    expanded: boolean;
    expandedChange: EventEmitter<boolean>;
    readonly hostClass = true;
    get isExpanded(): boolean;
    toggle(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<SicCollapseComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<SicCollapseComponent, "sic-collapse", never, { "label": { "alias": "label"; "required": false; }; "expanded": { "alias": "expanded"; "required": false; }; }, { "expandedChange": "expandedChange"; }, never, ["*"], true, never>;
}

/**
 * Coordinates a set of projected <sic-collapse> children so only one stays
 * open at a time, unless `multi` is set.
 */
declare class SicAccordionComponent implements AfterContentInit {
    multi: boolean;
    panels: QueryList<SicCollapseComponent>;
    readonly hostClass = true;
    ngAfterContentInit(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<SicAccordionComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<SicAccordionComponent, "sic-accordion", never, { "multi": { "alias": "multi"; "required": false; }; }, {}, ["panels"], ["sic-collapse"], true, never>;
}

declare class SicDialogComponent {
    open: boolean;
    title?: string;
    disableClose: boolean;
    width: string;
    openChange: EventEmitter<boolean>;
    closed: EventEmitter<void>;
    readonly hostClass = true;
    close(): void;
    handleBackdropClick(): void;
    handleEscape(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<SicDialogComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<SicDialogComponent, "sic-dialog", never, { "open": { "alias": "open"; "required": false; }; "title": { "alias": "title"; "required": false; }; "disableClose": { "alias": "disableClose"; "required": false; }; "width": { "alias": "width"; "required": false; }; }, { "openChange": "openChange"; "closed": "closed"; }, never, ["*", "[sicDialogFooter]"], true, never>;
}

/** Injected into the opened component: `data = inject(SIC_DIALOG_DATA) as MyDataType`. */
declare const SIC_DIALOG_DATA: InjectionToken<unknown>;
interface SicDialogConfig {
    width?: string;
    height?: string;
    disableClose?: boolean;
}
/**
 * Injected into the opened component (`inject(SicDialogRef)`) so it can close
 * itself and hand a result back to whoever called `SicDialogService.open()`.
 */
declare class SicDialogRef<T = unknown, R = unknown> {
    private readonly closeFn;
    componentInstance: T;
    constructor(closeFn: (result?: R) => void);
    close(result?: R): void;
}

/**
 * The Observable emits the value passed to `SicDialogRef.close(result)` once,
 * then completes — closing without a result (e.g. backdrop click or Escape)
 * emits `undefined`. `componentInstance`/`close` are attached to it directly
 * so callers that need them don't have to give up the `.subscribe(...)` form.
 */
type SicDialogHandle<T, R> = Observable<R | undefined> & {
    componentInstance: T;
    close: (result?: R) => void;
};
declare class SicDialogService {
    private readonly overlay;
    private readonly injector;
    open<T, D = unknown, R = unknown>(component: ComponentType<T>, data?: D, config?: SicDialogConfig): SicDialogHandle<T, R>;
    /** Icon + title + description + a single "Close" button. */
    info(title: string, description: string, config?: SicDialogConfig): Observable<void>;
    /** Icon + title + description + a single "Close" button. */
    success(title: string, description: string, config?: SicDialogConfig): Observable<void>;
    /** Icon + title + description + a single "Close" button. */
    danger(title: string, description: string, config?: SicDialogConfig): Observable<void>;
    /** Icon + title + description + a single "Close" button. */
    warning(title: string, description: string, config?: SicDialogConfig): Observable<void>;
    /** Icon + title + description + "Cancel"/"Confirm" buttons. Emits `true` if confirmed, `false` for cancel/backdrop/Escape. */
    confirm(title: string, description: string, config?: SicDialogConfig): Observable<boolean>;
    private openCommon;
    static ɵfac: i0.ɵɵFactoryDeclaration<SicDialogService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<SicDialogService>;
}

type SicCommonDialogType = 'info' | 'success' | 'danger' | 'warning' | 'confirm';
interface SicCommonDialogData {
    type: SicCommonDialogType;
    title: string;
    description: string;
    closeText?: string;
    cancelText?: string;
    confirmText?: string;
}
/**
 * Shared body for `SicDialogService.info/success/danger/warning/confirm()` —
 * icon on top, then title, then description, then a `sic-button` footer
 * (a single "Close" button, or "Cancel"/"Confirm" for the confirm type).
 */
declare class SicCommonDialogComponent {
    readonly data: SicCommonDialogData;
    private readonly dialogRef;
    private readonly sicConfig;
    readonly hostClass = true;
    get isConfirm(): boolean;
    get buttonColor(): 'primary' | 'success' | 'danger' | 'warning';
    get cancelText(): string;
    get confirmText(): string;
    get closeText(): string;
    close(result?: boolean): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<SicCommonDialogComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<SicCommonDialogComponent, "sic-common-dialog", never, {}, {}, never, never, true, never>;
}

/**
 * The actual visual "box" for every dialog opened via `SicDialogService`.
 * `SicDialogService.open()` attaches THIS component to the CDK overlay (not
 * the caller's component directly) so the panel look (background, radius,
 * shadow) comes from a real Angular `:host` style — a CDK overlay pane is a
 * plain DOM element outside any component's template, so a `panelClass`
 * string matched against some other component's scoped stylesheet can never
 * actually reach it. The caller's component is then created inside this
 * component's `ng-container` outlet via `attachContent()`.
 */
declare class SicDialogPanelComponent {
    private outlet;
    readonly hostClass = true;
    attachContent<T>(component: ComponentType$1<T>, injector: Injector): ComponentRef<T>;
    static ɵfac: i0.ɵɵFactoryDeclaration<SicDialogPanelComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<SicDialogPanelComponent, "sic-dialog-panel", never, {}, {}, never, never, true, never>;
}

interface SicLoadingState {
    message?: string;
    /** URL to a .png/.gif (or any image) shown instead of the default sic-spinner. */
    image?: string;
    spinnerSize: 'sm' | 'md' | 'lg';
}

/**
 * Body attached by `SicLoadingService.show()` — a `sic-spinner` (default) or a
 * custom png/gif image, plus an optional message.
 *
 * `ViewEncapsulation.None`: the CDK overlay's pane/backdrop elements
 * (`.sic-loading__panel`/`.sic-loading__backdrop`, set as `panelClass`/
 * `backdropClass` in `SicLoadingService`) live outside this component's own
 * template, as plain elements the Overlay created — Angular's normal emulated
 * encapsulation attribute would never match them, so those two rules need to
 * be unscoped to actually apply. This component is always the one instantiated
 * by `show()`, so its styles are guaranteed to be present by the time they're needed.
 */
declare class SicLoadingOverlayComponent {
    readonly state: i0.WritableSignal<SicLoadingState>;
    readonly hostClass = true;
    static ɵfac: i0.ɵɵFactoryDeclaration<SicLoadingOverlayComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<SicLoadingOverlayComponent, "sic-loading-overlay", never, {}, {}, never, never, true, never>;
}

interface SicLoadingOptions {
    message?: string;
    /** URL to a .png/.gif (or any image) shown instead of the default sic-spinner. */
    image?: string;
    spinnerSize?: 'sm' | 'md' | 'lg';
    /** Auto-hides after this many ms. Omitted or 0 means it stays up until `hide()` is called. */
    timeout?: number;
}
interface SicLoadingHandle {
    hide(): void;
    /** Updates the message on an already-shown overlay. */
    setMessage(message: string | undefined): void;
    /** Swaps to a custom image, or back to the default sic-spinner if `undefined`. */
    setImage(image: string | undefined): void;
    isVisible(): boolean;
}
declare class SicLoadingService {
    private readonly overlay;
    private readonly injector;
    private readonly sicConfig;
    show(options?: SicLoadingOptions): SicLoadingHandle;
    static ɵfac: i0.ɵɵFactoryDeclaration<SicLoadingService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<SicLoadingService>;
}

type SicToastType = 'info' | 'success' | 'danger' | 'warning' | 'neutral';
type SicToastPosition = 'top-right' | 'top-left' | 'bottom-right' | 'bottom-left' | 'top-center' | 'bottom-center';
/** One of the built-in icons, `false` to hide the icon entirely, or any other string (e.g. an emoji) to show as-is. */
type SicToastIcon = 'success' | 'danger' | 'warning' | 'info' | false | string;
interface SicToastBadge {
    text: string;
    /** Rendered inside the badge's dot. Defaults to a plain colored dot. */
    icon?: string;
}
interface SicToastOptions {
    /** Bold heading. Falls back to `message` alone (no heading) when omitted. */
    title?: string;
    message: string;
    type?: SicToastType;
    duration?: number;
    /** Overrides the icon normally implied by `type`. */
    icon?: SicToastIcon;
    /** A right-aligned pill, e.g. `{ text: '+500' }` for a reward-style toast. */
    badge?: SicToastBadge;
}
interface SicToast {
    id: number;
    title?: string;
    message: string;
    type: SicToastType;
    duration: number;
    icon?: SicToastIcon;
    badge?: SicToastBadge;
}
declare class SicToastService {
    readonly toasts: i0.WritableSignal<SicToast[]>;
    /** Quick form: `show('Saved', 'success')`. For a title, icon override, or badge, pass a `SicToastOptions` object instead. */
    show(message: string, type?: SicToastType, duration?: number): number;
    show(options: SicToastOptions): number;
    dismiss(id: number): void;
    clear(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<SicToastService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<SicToastService>;
}

declare const BUILTIN_ICON_KEYS: readonly ["success", "danger", "warning", "info"];
type SicToastBuiltinIcon = (typeof BUILTIN_ICON_KEYS)[number];
declare class SicToastComponent {
    position: SicToastPosition;
    readonly toastService: SicToastService;
    get hostClasses(): string;
    dismiss(id: number): void;
    /** `undefined` on the toast means "use the type's default icon" — `neutral` has none. */
    resolvedIcon(toast: SicToast): SicToastIcon;
    isBuiltinIcon(icon: SicToastIcon): icon is SicToastBuiltinIcon;
    static ɵfac: i0.ɵɵFactoryDeclaration<SicToastComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<SicToastComponent, "sic-toast", never, { "position": { "alias": "position"; "required": false; }; }, {}, never, never, true, never>;
}

declare class SicTooltipComponent {
    text: string;
    static ɵfac: i0.ɵɵFactoryDeclaration<SicTooltipComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<SicTooltipComponent, "sic-tooltip", never, { "text": { "alias": "text"; "required": false; }; }, {}, never, never, true, never>;
}

type SicTooltipPlacement = 'top' | 'bottom' | 'left' | 'right';
declare class SicTooltipDirective implements OnDestroy {
    text: string;
    sicTooltipPlacement: SicTooltipPlacement;
    private readonly overlay;
    private readonly host;
    private overlayRef?;
    show(): void;
    hide(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<SicTooltipDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<SicTooltipDirective, "[sicTooltip]", never, { "text": { "alias": "sicTooltip"; "required": false; }; "sicTooltipPlacement": { "alias": "sicTooltipPlacement"; "required": false; }; }, {}, never, never, true, never>;
}

/** Template context handed to a custom `<ng-template #itemTemplate let-item let-active="active">` result row. */
interface SicSearchItemContext<T> {
    $implicit: T;
    active: boolean;
    query: string;
}
/**
 * A ⌘K-style popup search: bind `[open]`/`(openChange)` (e.g. from a nav-bar search button),
 * pass `[items]`, and it renders a centered overlay with a text input and a filtered result list.
 * Closes on Escape or a backdrop click. Provide `<ng-template #itemTemplate>` to fully customize
 * how each result renders.
 */
declare class SicSearchComponent<T = unknown> implements OnChanges, OnDestroy {
    private readonly overlay;
    private readonly viewContainerRef;
    private readonly sicConfig;
    open: boolean;
    items: T[];
    query: string;
    placeholder: string;
    /** Property name to read the display label from, or a function computing it. Default: `String(item)`. */
    optionLabel: keyof T | ((item: T) => string);
    /** Full replacement for the built-in case-insensitive substring filter, e.g. for server-side search where `items` already arrives pre-filtered. */
    filterFn?: (items: T[], query: string) => T[];
    closeOnSelect: boolean;
    /** Minimum width of the search panel (any CSS length, e.g. `'24rem'`). Default: none. */
    minWidth?: string;
    openChange: EventEmitter<boolean>;
    queryChange: EventEmitter<string>;
    itemSelect: EventEmitter<T>;
    /** `<ng-template #itemTemplate let-item let-active="active" let-query="query">` overrides how each result renders. */
    itemTemplate?: TemplateRef<SicSearchItemContext<T>>;
    private readonly panelTemplateRef;
    activeIndex: number;
    private overlayRef?;
    get noResultsText(): string;
    get filteredItems(): T[];
    ngOnChanges(changes: SimpleChanges): void;
    ngOnDestroy(): void;
    onDocumentEscape(): void;
    labelFor(item: T): string;
    handleQueryInput(value: string): void;
    handleKeydown(event: KeyboardEvent): void;
    selectItem(item: T): void;
    close(): void;
    private openOverlay;
    private closeOverlay;
    static ɵfac: i0.ɵɵFactoryDeclaration<SicSearchComponent<any>, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<SicSearchComponent<any>, "sic-search", never, { "open": { "alias": "open"; "required": false; }; "items": { "alias": "items"; "required": false; }; "query": { "alias": "query"; "required": false; }; "placeholder": { "alias": "placeholder"; "required": false; }; "optionLabel": { "alias": "optionLabel"; "required": false; }; "filterFn": { "alias": "filterFn"; "required": false; }; "closeOnSelect": { "alias": "closeOnSelect"; "required": false; }; "minWidth": { "alias": "minWidth"; "required": false; }; }, { "openChange": "openChange"; "queryChange": "queryChange"; "itemSelect": "itemSelect"; }, ["itemTemplate"], never, true, never>;
}

/** Template context handed to the button/header/footer slot overrides: `let-popover="$implicit"`. */
interface SicPopoverTemplateContext {
    $implicit: unknown;
    open: boolean;
}
/** Template context handed to each rendered row: `let-item let-index="index"`. */
interface SicPopoverItemContext<T> {
    $implicit: T;
    index: number;
}
/** Wrap custom markup with `<ng-template sicPopoverButton let-popover>` to replace the default "⋯" trigger button — call `popover.toggle()` yourself. */
declare class SicPopoverButtonDirective {
    static ɵfac: i0.ɵɵFactoryDeclaration<SicPopoverButtonDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<SicPopoverButtonDirective, "[sicPopoverButton]", never, {}, {}, never, never, true, never>;
}
/** Wrap custom markup with `<ng-template sicPopoverHeader let-popover>` — the panel has no built-in header, so this is the only way to render one. */
declare class SicPopoverHeaderDirective {
    static ɵfac: i0.ɵɵFactoryDeclaration<SicPopoverHeaderDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<SicPopoverHeaderDirective, "[sicPopoverHeader]", never, {}, {}, never, never, true, never>;
}
/** Wrap custom markup with `<ng-template sicPopoverList let-item let-index="index">` to replace how each item in `items` renders. */
declare class SicPopoverListDirective {
    static ɵfac: i0.ɵɵFactoryDeclaration<SicPopoverListDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<SicPopoverListDirective, "[sicPopoverList]", never, {}, {}, never, never, true, never>;
}
/** Wrap custom markup with `<ng-template sicPopoverFooter let-popover>` — the panel has no built-in footer, so this is the only way to render one. */
declare class SicPopoverFooterDirective {
    static ɵfac: i0.ɵɵFactoryDeclaration<SicPopoverFooterDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<SicPopoverFooterDirective, "[sicPopoverFooter]", never, {}, {}, never, never, true, never>;
}

type SicPopoverPlacement = 'bottom-start' | 'bottom-end' | 'top-start' | 'top-end';
/**
 * A generic popover: a trigger button that opens a connected overlay panel showing `items` as a
 * list. Closes on Escape or a backdrop click. Every part is swappable — provide
 * `<ng-template sicPopoverButton>`/`sicPopoverHeader`/`sicPopoverList`/`sicPopoverFooter` to
 * customize the trigger, panel header, per-item rendering, and panel footer respectively.
 */
declare class SicPopoverComponent<T = unknown> implements OnChanges, OnDestroy {
    private readonly overlay;
    private readonly viewContainerRef;
    private readonly sicConfig;
    /**
     * The overlay anchors to the host element itself (not a `@ViewChild` wrapper inside the
     * template) — `:host` is given real `inline-flex` geometry in the stylesheet specifically so
     * this always has a genuine, immediately-available bounding rect to position against. An
     * earlier version anchored to a `display: contents` wrapper div instead, which has no box of
     * its own (`getBoundingClientRect()` returns a zero-size rect at the origin), sending the panel
     * to the top-left of the page instead of next to the trigger.
     */
    private readonly hostElementRef;
    items: T[];
    open: boolean;
    closeOnSelect: boolean;
    placement: SicPopoverPlacement;
    openChange: EventEmitter<boolean>;
    itemSelect: EventEmitter<T>;
    /** Custom `<ng-template sicPopoverButton let-popover>` replaces the default "⋯" trigger button — call `popover.toggle()` yourself. */
    buttonTemplate?: TemplateRef<SicPopoverTemplateContext>;
    /** `<ng-template sicPopoverHeader let-popover>` — the panel has no built-in header, so this is the only way to render one. */
    headerTemplate?: TemplateRef<SicPopoverTemplateContext>;
    /** `<ng-template sicPopoverList let-item let-index="index">` overrides how each item in `items` renders. */
    listTemplate?: TemplateRef<SicPopoverItemContext<T>>;
    /** `<ng-template sicPopoverFooter let-popover>` — the panel has no built-in footer, so this is the only way to render one. */
    footerTemplate?: TemplateRef<SicPopoverTemplateContext>;
    private readonly panelTemplateRef;
    private overlayRef?;
    get templateContext(): SicPopoverTemplateContext;
    get noItemsText(): string;
    ngOnChanges(changes: SimpleChanges): void;
    ngOnDestroy(): void;
    onDocumentEscape(): void;
    toggle(): void;
    close(): void;
    selectItem(item: T): void;
    private openSelf;
    private openOverlay;
    private closeOverlay;
    static ɵfac: i0.ɵɵFactoryDeclaration<SicPopoverComponent<any>, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<SicPopoverComponent<any>, "sic-popover", never, { "items": { "alias": "items"; "required": false; }; "open": { "alias": "open"; "required": false; }; "closeOnSelect": { "alias": "closeOnSelect"; "required": false; }; "placement": { "alias": "placement"; "required": false; }; }, { "openChange": "openChange"; "itemSelect": "itemSelect"; }, ["buttonTemplate", "headerTemplate", "listTemplate", "footerTemplate"], never, true, never>;
}

declare class SicSpinnerComponent {
    size: 'sm' | 'md' | 'lg';
    readonly hostClass = true;
    get isSm(): boolean;
    get isLg(): boolean;
    static ɵfac: i0.ɵɵFactoryDeclaration<SicSpinnerComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<SicSpinnerComponent, "sic-spinner", never, { "size": { "alias": "size"; "required": false; }; }, {}, never, never, true, never>;
}

declare class SicSkeletonComponent {
    variant: 'text' | 'circle' | 'rect';
    width: string;
    height?: string;
    get hostClasses(): string;
    get hostWidth(): string;
    get hostHeight(): string;
    static ɵfac: i0.ɵɵFactoryDeclaration<SicSkeletonComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<SicSkeletonComponent, "sic-skeleton", never, { "variant": { "alias": "variant"; "required": false; }; "width": { "alias": "width"; "required": false; }; "height": { "alias": "height"; "required": false; }; }, {}, never, never, true, never>;
}

declare class SicProgressBarComponent {
    value: number;
    indeterminate: boolean;
    color: 'primary' | 'success' | 'danger' | 'warning';
    readonly hostClass = true;
    readonly role = "progressbar";
    get ariaValueNow(): number | null;
    get clampedValue(): number;
    static ɵfac: i0.ɵɵFactoryDeclaration<SicProgressBarComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<SicProgressBarComponent, "sic-progress-bar", never, { "value": { "alias": "value"; "required": false; }; "indeterminate": { "alias": "indeterminate"; "required": false; }; "color": { "alias": "color"; "required": false; }; }, {}, never, never, true, never>;
}

/** Which decorative pattern `sic-space-bg` renders. */
type SicSpaceBgVariant = 'hexagon' | 'geometric' | 'gradient' | 'sparkle';
/** Which built-in default palette to use when `[colors]` is empty. `'auto'` follows `SicThemeService.isDark()`. */
type SicSpaceBgColorMode = 'auto' | 'light' | 'dark';
/** One scattered shape/sparkle, laid out deterministically from `[seed]`. Not used by the `'gradient'` variant. */
interface SicSpaceBgShape {
    id: number;
    /** Position, in percent of the host's width/height. */
    left: number;
    top: number;
    /** Multiplier applied to `[size]` for this shape. */
    size: number;
    /** Animation delay/duration, in seconds. */
    delay: number;
    duration: number;
    opacity: number;
    color: string;
    /** Static rotation, in degrees. */
    rotate: number;
    /** Only set for `'geometric'` — cycles through the 4 kinds across the scattered shapes. */
    kind?: 'circle' | 'square' | 'triangle' | 'hexagon';
}

/**
 * A decorative, fully CSS-driven animated background layer — fills its container at 100% width/
 * height. Four variants: `'hexagon'` and `'geometric'` scatter floating clip-path shapes,
 * `'sparkle'` twinkles small dots, and `'gradient'` shifts an animated linear-gradient. Shape
 * layout is randomized but deterministic (seeded via `[seed]`), so it doesn't reshuffle on every
 * change detection or differ between server and client renders.
 */
declare class SicSpaceBgComponent {
    private readonly themeService;
    /** Which decorative pattern to render. Default: `'gradient'`. */
    variant: SicSpaceBgVariant;
    /** Palette used to color the pattern (gradient stops, shape fills, sparkle dots). Falls back to a built-in light/dark default for the current `[variant]` when empty (see `[colorMode]`). */
    colors: string[];
    /** Which built-in default palette to fall back to when `[colors]` is empty. `'auto'` (default) follows `SicThemeService.isDark()`, so the same markup looks right in both light and dark mode without passing `[colors]` explicitly. */
    colorMode: SicSpaceBgColorMode;
    /** Base background color behind the pattern, e.g. a dark backdrop for `'sparkle'`. Default: `'transparent'`. */
    backgroundColor: string;
    /** Plays the floating/twinkling/gradient-shift animation. Default: true. */
    animated: boolean;
    /** Animation duration in seconds — smaller is faster. Default: 20. */
    animationSpeed: number;
    /** Number of shapes/sparkles to scatter. Ignored by `'gradient'`. Default: 24. */
    density: number;
    /** Base shape size, as a CSS length (e.g. `'2rem'`). Each shape scales it by a random factor. Default: `'2rem'`. */
    size: string;
    /** Overall opacity of the pattern layer, 0–1. Default: 0.5. */
    opacity: number;
    /** CSS blur amount applied to the pattern layer (e.g. `'2px'`) for a soft glow look. Default: `'0px'`. */
    blur: string;
    /** Angle, in degrees, of the `'gradient'` variant's linear gradient. Default: 135. */
    gradientAngle: number;
    /** Seeds the deterministic pseudo-random layout — same seed always produces the same scatter of shapes. Default: 1. */
    seed: number;
    readonly hostClass = true;
    get isDarkClass(): boolean;
    get isLightClass(): boolean;
    get hostBackground(): string;
    get speedVar(): string;
    /** Resolves `[colorMode]` against `SicThemeService.isDark()` when set to `'auto'`. */
    get effectiveDark(): boolean;
    get palette(): string[];
    get gradientBackground(): string;
    get shapes(): SicSpaceBgShape[];
    trackByFn: (_: number, shape: SicSpaceBgShape) => number;
    static ɵfac: i0.ɵɵFactoryDeclaration<SicSpaceBgComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<SicSpaceBgComponent, "sic-space-bg", never, { "variant": { "alias": "variant"; "required": false; }; "colors": { "alias": "colors"; "required": false; }; "colorMode": { "alias": "colorMode"; "required": false; }; "backgroundColor": { "alias": "backgroundColor"; "required": false; }; "animated": { "alias": "animated"; "required": false; }; "animationSpeed": { "alias": "animationSpeed"; "required": false; }; "density": { "alias": "density"; "required": false; }; "size": { "alias": "size"; "required": false; }; "opacity": { "alias": "opacity"; "required": false; }; "blur": { "alias": "blur"; "required": false; }; "gradientAngle": { "alias": "gradientAngle"; "required": false; }; "seed": { "alias": "seed"; "required": false; }; }, {}, never, never, true, never>;
}

interface Person {
    name: string;
    role: string;
}
/** Rendered through sic-gridpanel's [config] — the index signature is what makes each doc row assignable to SicGridRowData. */
interface ComponentAttributeDoc {
    [key: string]: unknown;
    name: string;
    type: string;
    default?: string;
    description: string;
}
/** Rendered through sic-gridpanel's [config] — the index signature is what makes each doc row assignable to SicGridRowData. */
interface ComponentEventDoc {
    [key: string]: unknown;
    name: string;
    payload: string;
    description: string;
}
interface SicDocCodeBlock {
    id: string;
    label: string;
    lang: SicCodeLanguage;
    code: string;
}
interface ComponentDoc {
    id: string;
    selector: string;
    title: string;
    category: string;
    description: string;
    code: string;
    /** Tab label for `code` — defaults to 'template.html'. Override for docs where `code` isn't an Angular template (CLI commands, bootstrap config, plain TS/interfaces, etc). */
    codeLabel?: string;
    /** Syntax highlighting language for `code` — defaults to 'html'. */
    codeLang?: SicCodeLanguage;
    /** Relevant slice of the tutorial page's own component.ts backing the demo above, if any. */
    tsCode?: string;
    /** Tab label for `tsCode` — defaults to 'component.ts'. */
    tsCodeLabel?: string;
    /** Syntax highlighting language for `tsCode` — defaults to 'typescript'. */
    tsCodeLang?: SicCodeLanguage;
    /** For docs spanning more than 2 real files (e.g. install: CLI + styles.css + app.config.ts) — overrides `code`/`tsCode` entirely, one tab per block. */
    codeBlocks?: SicDocCodeBlock[];
    /** False for Setup docs with no interactive preview (e.g. install, sic-config) — hides the empty "Demo" card instead of showing it blank. Defaults to true. */
    hasDemo?: boolean;
    attributes: ComponentAttributeDoc[];
    events: ComponentEventDoc[];
}
interface ComponentGroup {
    id: string;
    title: string;
    description: string;
    components: ComponentDoc[];
}
declare class TutorialPageComponent {
    fb: FormBuilder;
    private toasts;
    themeService: SicThemeService;
    private sicDialogService;
    private sicLoadingService;
    form: FormGroup;
    codeTab: string;
    /**
     * One tab per real file backing a doc's code example. Most docs are just
     * `code` (template.html) + optional `tsCode` (component.ts); docs spanning
     * more than 2 files (e.g. install: CLI + styles.css + app.config.ts) set
     * `codeBlocks` directly instead.
     */
    blocksFor(doc: ComponentDoc): SicDocCodeBlock[];
    codeTabsFor(doc: ComponentDoc): SicTab[];
    activeBlockFor(doc: ComponentDoc): SicDocCodeBlock;
    constructor(fb: FormBuilder, toasts: SicToastService, themeService: SicThemeService, sicDialogService: SicDialogService, sicLoadingService: SicLoadingService);
    toggleTheme(): void;
    /** Drives SIC_CONFIG.locale/era/messages for every sic-* component on the page — see sicConfigValue above. */
    uiLanguage: 'th' | 'en';
    toggleLanguage(): void;
    readonly themeNames: SicThemeName[];
    setThemeName(name: SicThemeName): void;
    demoCustomColor: string | null;
    applyCustomColor(): void;
    /** Renders each doc's "Attributes"/"Events" section — small, read-only, non-paginated grids. */
    readonly attributesGridConfig: SicGridPanelConfig;
    readonly eventsGridConfig: SicGridPanelConfig;
    /** `default` is optional per attribute — most docs use it, but a few (events-only services,
     * template-only slots, etc.) never set it on any of their attributes. Showing that column full of
     * "-" placeholders for those docs is just noise, so hide it entirely when nothing in this doc's
     * attributes would fill it. */
    attributesGridConfigFor(doc: ComponentDoc): SicGridPanelConfig;
    email: string;
    password: string;
    age: number | null;
    price: number | null;
    bio: string;
    phone: string;
    selectedPerson: Person | null;
    people: Person[];
    agree: boolean;
    notifyBy: 'email' | 'sms';
    shippingMethod: string;
    shippingOptions: SicRadioOption[];
    darkMode: boolean;
    volumeRange: number;
    priceRange: [number, number];
    birthday: string;
    eventDate: string | null;
    billingMonth: string | null;
    meetingTime: Date | null;
    supportTime: Date | null;
    supportWindowStart: Date;
    supportWindowEnd: Date;
    startDateTime: FormControl<Date | null>;
    endDateTime: FormControl<Date | null>;
    brandColor: string | null;
    files: File[];
    rating: number;
    readonly demoContactForm: FormGroup;
    readonly demoContactData: SicFormData<{
        name: string;
    }>;
    demoContactDelete(): void;
    demoContactRestore(): void;
    demoContactReset(): void;
    demoContactMarkAsPristine(): void;
    readonly combineItemsConfig: SicGridPanelConfig;
    private combineItemsSourceRows;
    readonly combineExtrasConfig: SicGridPanelConfig;
    private combineExtrasSourceRows;
    combineResult: string;
    handleCombineItemsLoad(request: SicGridLoadRequest, grid: SicGridPanelComponent): void;
    handleCombineExtrasLoad(request: SicGridLoadRequest, grid: SicGridPanelComponent): void;
    private buildCombine;
    combineSubmit(itemsGrid: SicGridPanelComponent, extrasGrid: SicGridPanelComponent): void;
    combineRestore(itemsGrid: SicGridPanelComponent, extrasGrid: SicGridPanelComponent): void;
    combineReset(itemsGrid: SicGridPanelComponent, extrasGrid: SicGridPanelComponent): void;
    readonly standardEmployeeForm: FormGroup;
    readonly standardEmployeeData: SicFormData<{
        employeeCode: string;
        employeeName: string;
        department: string;
        position: string;
        salary: number;
    }>;
    standardSave(): void;
    readonly standardSearchForm: FormGroup;
    readonly standardDepartmentOptions: {
        label: string;
        value: string;
    }[];
    readonly standardPositionOptions: {
        label: string;
        value: string;
    }[];
    readonly standardSearchGridConfig: SicGridPanelConfig;
    private readonly standardSearchSourceRows;
    handleStandardSearchLoad(request: SicGridLoadRequest, grid: SicGridPanelComponent): void;
    handleStandardSearchRowAction(event: {
        action: string;
        row?: SicGridRowData | null;
    }): void;
    standardSearchSubmit(grid: SicGridPanelComponent): void;
    standardSearchClear(): void;
    readonly standardHistoryGridConfig: SicGridPanelConfig;
    private readonly standardHistorySourceRows;
    handleStandardHistoryLoad(request: SicGridLoadRequest, grid: SicGridPanelComponent): void;
    standardTransactionSave(historyGrid: SicGridPanelComponent): void;
    sidebarItems: SicSidebarItem[];
    sidebarSections: SicSidebarSection[];
    sidebarUser: SicSidebarUser;
    sidebarCollapsed: boolean;
    sidebarSearch: string;
    navbarCollapsed: boolean;
    navbarDarkMode: boolean;
    navbarUser: SicNavbarUser;
    navbarMenuItems: SicNavbarMenuItem[];
    navbarNotifications: SicNavbarNotification[];
    shellCollapsed: boolean;
    shellActiveLink: string;
    shellDarkMode: boolean;
    get shellHasUnreadNotifications(): boolean;
    get shellBreadcrumbItems(): SicBreadcrumbItem[];
    private findSidebarPath;
    handleShellItemSelect(item: SicSidebarItem): void;
    handleShellBreadcrumbClick(item: SicBreadcrumbItem): void;
    shellCollapsedV2: boolean;
    shellActiveLinkV2: string;
    shellDarkModeV2: boolean;
    get shellBreadcrumbItemsV2(): SicBreadcrumbItem[];
    handleShellItemSelectV2(item: SicSidebarItem): void;
    handleShellBreadcrumbClickV2(item: SicBreadcrumbItem): void;
    tabs: SicTab[];
    activeTabId: string;
    wizardSteps: SicStepperStep[];
    wizardStep: number;
    onWizardSkip(skippedIndex: number): void;
    onWizardFinish(): void;
    companyHistory: SicTimelineItem[];
    timelineOrientation: 'horizontal' | 'vertical';
    timelineAlternate: boolean;
    breadcrumbItems: SicBreadcrumbItem[];
    gridConfig: SicGridPanelConfig;
    private gridSourceRows;
    handleGridLoad(request: SicGridLoadRequest, grid: SicGridPanelComponent): void;
    handleGridSave(request: SicGridSaveRequest, grid: SicGridPanelComponent): void;
    handleSidebarUserAction(user: SicSidebarUser): void;
    handleNavbarMenuItem(item: SicNavbarMenuItem): void;
    handleNavbarNotification(notification: SicNavbarNotification): void;
    handleNavbarViewAll(): void;
    handleGridRowAction(event: {
        action: string;
        row?: SicGridRowData | null;
    }): void;
    calendarEra: SicCalendarEra;
    calendarView: SicCalendarView;
    readonly calendarTasks: SicCalendarEvent[];
    readonly calendarHolidays: SicCalendarHoliday[];
    private dayOffset;
    handleCalendarEventClick(event: SicCalendarEvent): void;
    handleCalendarHolidayClick(holiday: SicCalendarHoliday): void;
    handleCalendarDateClick(event: {
        date: Date;
        tasks: SicCalendarEvent[];
        holidays: SicCalendarHoliday[];
    }): void;
    handleCalendarMonthChange(date: Date): void;
    ganttShowLabels: boolean;
    ganttViewMode: 'day' | 'week' | 'month';
    readonly ganttRows: SicCalendarTimelineRow[];
    onGanttRowClick(row: SicCalendarTimelineRow): void;
    onGanttPhaseClick(event: {
        row: SicCalendarTimelineRow;
        phase: SicCalendarTimelinePhase;
    }): void;
    readonly codeSnippet: string;
    dialogOpen: boolean;
    progressValue: number;
    searchOpen: boolean;
    readonly searchPages: {
        label: string;
        path: string;
    }[];
    onSearchSelect(page: {
        label: string;
        path: string;
    }): void;
    readonly menuActions: {
        label: string;
        icon: string;
    }[];
    onMenuActionSelect(action: {
        label: string;
        icon: string;
    }): void;
    readonly masonryPhotos: {
        title: string;
        height: number;
    }[];
    onMasonryItemClick(photo: {
        title: string;
        height: number;
    }): void;
    readonly kanbanLists: SicDragDropList<{
        id: number;
        title: string;
    }>[];
    onCardMoved(event: SicDragDropMoveEvent<{
        id: number;
        title: string;
    }>): void;
    readonly componentGroups: ComponentGroup[];
    get totalComponents(): number;
    readonly libraryVersion: string;
    tocActiveLink: string | null;
    tocCollapsed: boolean;
    readonly quickstartSnippet: string;
    get tocSections(): SicSidebarSection[];
    get tocBreadcrumbItems(): SicBreadcrumbItem[];
    handleTocSelect(item: SicSidebarItem): void;
    componentSearchOpen: boolean;
    get componentSearchItems(): {
        label: string;
        selector: string;
        link: string;
    }[];
    handleComponentSearchSelect(item: {
        label: string;
        selector: string;
        link: string;
    }): void;
    submit(): void;
    notify(): void;
    notifyCustomToasts(): void;
    onTagClosed(): void;
    skillTags: SicTagItem[];
    onSkillTagClosed(event: {
        item: SicTagItem;
        index: number;
    }): void;
    onAvatarClick(): void;
    teamAvatars: SicAvatarItem[];
    onTeamAvatarClick(event: {
        item: SicAvatarItem;
        index: number;
    }): void;
    openCommonDialog(type: 'info' | 'success' | 'danger' | 'warning'): void;
    openConfirmDialog(): void;
    showSpinnerLoading(): void;
    showImageLoading(): void;
    keywords: string;
    openServiceDialog(): void;
    comment: string;
    searchMentions: (query: string) => SicCommentMentionOption[];
    onMentionClick(option: SicCommentMentionOption): void;
    onHashtagClick(tag: string): void;
    onCommentFilesChange(files: File[]): void;
    viewCommentText: string;
    viewCommentAttachments: SicViewCommentAttachment[];
    private readonly viewCommentUserDirectory;
    resolveViewCommentMention: (usernameOrId: string) => string | undefined;
    onViewCommentMentionClick(name: string): void;
    onViewCommentHashtagClick(tag: string): void;
    onViewCommentAttachmentClick(attachment: SicViewCommentAttachment): void;
    destinations: SicCardStackItem[];
    onCardStackActive(index: number): void;
    slides: SicImageSliderItem[];
    onSlideChange(event: {
        index: number;
        item: SicImageSliderItem;
    }): void;
    onSlideEnd(): void;
    onPreviousTrack(): void;
    onNextTrack(): void;
    spaceBgPresetIndex: number;
    readonly spaceBgPresets: {
        label: string;
        variant: SicSpaceBgVariant;
        colors?: string[];
        colorMode?: 'auto' | 'light' | 'dark';
        density?: number;
        animationSpeed?: number;
        size?: string;
        opacity?: number;
        blur?: string;
        gradientAngle?: number;
        backgroundColor?: string;
        animated?: boolean;
    }[];
    get spaceBgPreset(): {
        label: string;
        variant: SicSpaceBgVariant;
        colors?: string[];
        colorMode?: "auto" | "light" | "dark";
        density?: number;
        animationSpeed?: number;
        size?: string;
        opacity?: number;
        blur?: string;
        gradientAngle?: number;
        backgroundColor?: string;
        animated?: boolean;
    };
    static ɵfac: i0.ɵɵFactoryDeclaration<TutorialPageComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<TutorialPageComponent, "sic-tutorial-page", never, {}, {}, never, never, true, never>;
}

export { SIC_CONFIG, SIC_DEFAULT_PHONE_COUNTRIES, SIC_DIALOG_DATA, SIC_SKIP_DEACTIVATE_GUARD, SIC_THEME_CONFIG, SicALinkComponent, SicAccordionComponent, SicAvatarComponent, SicBadgeComponent, SicBreadcrumbComponent, SicButtonComponent, SicButtonGroupComponent, SicCalendarComponent, SicCalendarTimelineComponent, SicCardComponent, SicCardStackComponent, SicCheckboxComponent, SicCodeComponent, SicCollapseComponent, SicColorpickerComponent, SicComboboxComponent, SicCommonDialogComponent, SicDatepickerComponent, SicDialogComponent, SicDialogPanelComponent, SicDialogRef, SicDialogService, SicDragDropComponent, SicEntityState, SicFlexComponent, SicFormControlBase, SicFormData, SicGridComponent, SicGridPanelComponent, SicGridPanelTemplate, SicIconBadgeComponent, SicImageComponent, SicImageSliderComponent, SicInputAreaComponent, SicInputCommentComponent, SicInputComponent, SicInputNumberComponent, SicInputPasswordComponent, SicInputPhoneComponent, SicInputTagComponent, SicLoadingOverlayComponent, SicLoadingService, SicMasonryComponent, SicNavbarComponent, SicNavbarHeaderDirective, SicNavbarLeftDirective, SicNavbarRightDirective, SicPopoverButtonDirective, SicPopoverComponent, SicPopoverFooterDirective, SicPopoverHeaderDirective, SicPopoverListDirective, SicProgressBarComponent, SicRadioComponent, SicRangeComponent, SicRatingComponent, SicSearchComponent, SicSectionComponent, SicShowComponent, SicSidebarComponent, SicSidebarFooterDirective, SicSidebarHeaderDirective, SicSidebarMenuDirective, SicSidebarSubheaderDirective, SicSkeletonComponent, SicSoundPlayerComponent, SicSpaceBgComponent, SicSpinnerComponent, SicStepperComponent, SicSwitchComponent, SicTabsComponent, SicTagComponent, SicTextComponent, SicThemeService, SicTimelineComponent, SicTimepickerComponent, SicToastComponent, SicToastService, SicTooltipComponent, SicTooltipDirective, SicUploadComponent, SicValidator, SicVideoPlayerComponent, SicViewCommentComponent, TutorialPageComponent, applySicFontFaces, applySicThemeConfig, createSicFormGroup, injectSicConfig, provideSicConfig, provideSicTheme, resolveMentionDisplay, sicCanDeactivateGuard, sicFormCombine, sicWarnBeforeUnload, splitCommentHighlightParts, tokenizeCode };
export type { SicAvatarItem, SicBadgePosition, SicBreadcrumbItem, SicButtonSize, SicButtonVariant, SicCalendarEra, SicCalendarEvent, SicCalendarHoliday, SicCalendarHolidaySource, SicCalendarTimelineEra, SicCalendarTimelineLabelContext, SicCalendarTimelinePhase, SicCalendarTimelinePhaseContext, SicCalendarTimelineRow, SicCalendarTimelineViewMode, SicCalendarView, SicCanComponentDeactivate, SicCardStackContext, SicCardStackItem, SicCodeLanguage, SicCodeToken, SicCodeTokenType, SicComboboxDisplayContext, SicComboboxOptionContext, SicComboboxQueryEvent, SicComboboxValue, SicCommentMentionOption, SicCommentMentionSearch, SicCommentTextPart, SicCommonDialogData, SicCommonDialogType, SicConfig, SicDateEra, SicDatepickerMode, SicDialogConfig, SicDialogHandle, SicDragDropColumnHeaderContext, SicDragDropItemContext, SicDragDropList, SicDragDropMoveEvent, SicFlexAlign, SicFlexJustify, SicFontFace, SicFontFaceSource, SicFormCombineResult, SicFormCombineSource, SicGridColumnAction, SicGridColumnConfig, SicGridColumnGroupConfig, SicGridGrandSummaryConfig, SicGridLoadRequest, SicGridOption, SicGridPanelConfig, SicGridPanelTemplateSection, SicGridRowData, SicGridSaveRequest, SicGridSummaryConfig, SicGridSummaryType, SicGridToolbarConfig, SicImageAsyncStrategy, SicImageMode, SicImageSliderContext, SicImageSliderItem, SicInputType, SicLoadingHandle, SicLoadingOptions, SicMasonryEntry, SicMasonryItemContext, SicMasonryLoadEvent, SicMessages, SicNavbarMenuItem, SicNavbarNotification, SicNavbarTemplateContext, SicNavbarUser, SicPhoneCountry, SicPopoverItemContext, SicPopoverPlacement, SicPopoverTemplateContext, SicRadioDirection, SicRadioOption, SicRangeValue, SicSearchItemContext, SicShowBreakpoint, SicSidebarItem, SicSidebarSection, SicSidebarTemplateContext, SicSidebarUser, SicSize, SicSpaceBgColorMode, SicSpaceBgShape, SicSpaceBgVariant, SicStateModel, SicStepperOrientation, SicStepperStep, SicTab, SicTagColor, SicTagItem, SicTextAlign, SicTextColor, SicTextSize, SicTextWeight, SicThemeConfig, SicThemeMode, SicThemeName, SicTimeSegment, SicTimelineItem, SicTimelineItemContext, SicTimelineOrientation, SicTimelineSide, SicToast, SicToastBadge, SicToastIcon, SicToastOptions, SicToastPosition, SicToastType, SicTooltipPlacement, SicUploadProgress, SicViewCommentAttachment, ToForm };
